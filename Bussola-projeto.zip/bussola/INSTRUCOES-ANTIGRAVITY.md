# Instruções para o Antigravity (ou outro agente de IA): gerar o APK da Bússola

Contexto: este projeto é um navegador para Android (Galaxy A32, Android 11) chamado Bússola. A interface é HTML, CSS e JavaScript (`web/`) e o app é um projeto Android em Java (`android/`), sem AndroidX. O código Java foi escrito sem nunca ter sido compilado, porque o ambiente onde foi criado não tinha o Android SDK. O seu trabalho é compilar, corrigir o que quebrar e entregar o APK.

## Objetivo

Gerar `android/app/build/outputs/apk/debug/app-debug.apk` com `./gradlew assembleDebug` (no Windows, `gradlew.bat assembleDebug`) e informar o caminho completo do arquivo.

## Passos

1. Confira o Java: `java -version` precisa mostrar a versão 17. O JDK que vem com o Android Studio serve. Se não houver nenhum, instale o JDK 17 (Temurin).
2. Confira o Android SDK. Procure as variáveis `ANDROID_HOME` ou `ANDROID_SDK_ROOT` e as pastas padrão (Windows: `%LOCALAPPDATA%\Android\Sdk`; macOS: `~/Library/Android/sdk`; Linux: `~/Android/Sdk`). Se não existir, instale as "command-line tools" do Android SDK e rode:
   `sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"`
   Aceite as licenças com `sdkmanager --licenses`.
3. Crie `android/local.properties` com a linha `sdk.dir=<caminho do SDK>` (no Windows, use `/` ou `\\` nas barras). Esse arquivo não deve ir para o Git.
4. Entre em `android` e rode `./gradlew assembleDebug`. Na primeira vez ele baixa o Gradle 8.9 e as dependências, então precisa de internet.
5. Se houver erros de compilação, corrija-os nos arquivos de `android/app/src/main/java/br/bussola/browser/` com o menor ajuste possível. Regras:
   - minSdk 26, compileSdk e targetSdk 34, sem AndroidX e sem bibliotecas externas.
   - Não mude o comportamento nem o visual. Não mexa em `web/`, a não ser que um erro aponte para lá.
   - A interface e o Java conversam por uma ponte: comandos e eventos em `web/js/engine.js`, e do lado Android em `Bridge.java`, `MainActivity.java` e `PageManager.java`. Se mudar o nome de um comando ou de um campo, mude dos dois lados.
   - Repita o passo 4 até o build terminar com `BUILD SUCCESSFUL`.
6. Avisos de API obsoleta (`deprecation`) são esperados e podem ser ignorados.
7. No final, responda em português, de forma curta: (a) o caminho completo do APK; (b) os arquivos e linhas que você alterou e por quê; (c) qualquer dúvida que ficou.

## Opcional: testar num emulador ou num celular com depuração USB

`adb install -r android/app/build/outputs/apk/debug/app-debug.apk` e abra o app "Bússola". Confira:

- a página inicial aparece com os favoritos;
- digitar um endereço abre o site;
- o botão de abas mostra a grade de abas;
- a barra de baixo encolhe ao rolar a página e volta ao rolar para cima;
- o botão Voltar do Android fecha menus e telas antes de voltar na página.

Se algo falhar, junte o texto do `adb logcat` (filtre por `chromium` e `AndroidRuntime`) e inclua na resposta.

## Como levar para o A32

Copie o `app-debug.apk` para o celular (cabo USB, Google Drive…) e toque nele. Se o Android pedir, permita "Instalar apps desconhecidos" para o aplicativo que abriu o arquivo. O Play Protect pode avisar que o app não é conhecido, porque a chave é de depuração: toque em "Instalar mesmo assim".

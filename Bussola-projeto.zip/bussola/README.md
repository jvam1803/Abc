# Bússola

Navegador para Android, feito para o Galaxy A32, com a interface e a interatividade do Safari do iOS 26: barra flutuante de "vidro líquido", abas em grade, modo leitura e página inicial com favoritos. Tudo em **branco, preto e cinza**, com o cinza em destaque.

> "Bússola" é um nome e um ícone próprios (uma estrela de quatro pontas). O projeto não usa marcas, ícones nem arquivos da Apple.

## O que tem aqui

| Pasta | O que é |
|---|---|
| `web/` | A interface inteira (HTML, CSS e JavaScript, sem dependências). Funciona sozinha no navegador, como PWA, e também é a tela do app Android. |
| `android/` | Projeto Android (Java, sem bibliotecas externas) que carrega a interface e abre cada site numa WebView de verdade. |
| `.github/workflows/` | Receita para o GitHub compilar o APK por você, sem instalar nada. |
| `INSTRUCOES-ANTIGRAVITY.md` | Passo a passo para um agente de IA (como o Antigravity) compilar o APK no seu computador e corrigir erros pequenos. |

## O que ele faz

- Barra de endereço e barra de ferramentas flutuantes, de vidro cinza. Ao rolar a página, a barra encolhe para uma pílula.
- Abas em grade com miniaturas, arrastar para fechar, abas privadas e "Fechar outras abas".
- Página inicial com Favoritos, Relatório de Privacidade, Lista de Leitura e Visitados com frequência.
- Leitor (modo leitura) com tamanho de texto e quatro temas (branco, prata, cinza e preto), buscar na página, zoom do texto, site para computador, imprimir ou salvar em PDF e compartilhar.
- Menu de toque longo em links e imagens: abrir em nova aba ou aba privada, copiar, baixar a imagem.
- Histórico, favoritos, lista de leitura e downloads.
- Bloqueador de anúncios e rastreadores conhecidos (só no app Android).
- Buscas: Google, DuckDuckGo, Bing, Brave Search, Ecosia e Wikipédia, com sugestões enquanto você digita.
- Aparência automática, clara ou escura. O escuro é preto com cinzas.
- O botão Voltar do Android fecha primeiro menus e telas abertas e só depois volta na página.

## 1. Testar agora, sem compilar (versão web)

A pasta `web/` roda em qualquer navegador moderno. Para usar como app no A32:

1. Hospede a pasta `web/` em qualquer lugar que sirva arquivos estáticos com **HTTPS** (GitHub Pages, Netlify, Cloudflare Pages…). O PWA exige HTTPS.
2. Abra o endereço no Chrome do celular, toque em **⋮** e escolha **Instalar app** (ou **Adicionar à tela inicial**).

Para ver no computador sem hospedar nada: `cd web && python3 -m http.server 8000` e abra `http://localhost:8000`.

A versão web é só uma prévia da interface. Por ela rodar dentro de um navegador, os sites aparecem em quadros (`iframe`), e muitos sites (Google, YouTube, bancos, redes sociais…) proíbem isso. Nesses casos aparece um aviso com o botão **Abrir no navegador do sistema**. Por isso a busca padrão da versão web é a Wikipédia. O app Android não tem essa limitação.

## 2. Gerar o app Android (APK)

### Opção A: pelo GitHub, sem instalar nada

O GitHub compila o app por você e entrega o APK. Use o jeito A1 se você só tem o celular, ou o A2 se estiver num computador.

#### A1. Só com o celular (um zip e um arquivo de texto)

1. Crie uma conta em [github.com](https://github.com) e um repositório novo (**New repository**; pode ser privado). Marque **Add a README file**, para ele não nascer vazio.
2. No repositório, toque em **Add file → Upload files**, escolha o arquivo `Bussola-projeto.zip` **sem descompactar** e toque em **Commit changes**.
3. Toque em **Add file → Create new file**. No campo do nome, digite `.github/workflows/apk.yml` (cada barra cria uma pasta). Cole a receita abaixo e toque em **Commit changes**. (Outro jeito: aba **Actions** → **set up a workflow yourself**, que já abre o editor no lugar certo.)
4. Abra a aba **Actions**. A execução "Gerar APK (a partir do zip)" começa sozinha e leva de 5 a 10 minutos.
5. Quando ela ficar verde, volte à página inicial do repositório e abra **Releases** (role a página; no computador fica na coluna da direita): lá está o `Bussola.apk`. Se a Release não aparecer, abra a execução em **Actions** e baixe **Bussola-APK**, na seção *Artifacts* (vem dentro de um `.zip`).

Receita do passo 3:

```yaml
name: Gerar APK (a partir do zip)

on:
  push:
  workflow_dispatch:

permissions:
  contents: write

jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Descompactar o projeto
        run: |
          mkdir projeto
          for z in *.zip; do unzip -q -o "$z" -d projeto; done
          test -n "$(find projeto -name settings.gradle)" || { echo "Nao achei o projeto Android dentro do zip"; exit 1; }

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'

      - name: Compilar o APK
        run: |
          cd "$(dirname "$(find projeto -name settings.gradle | head -n 1)")"
          gradle assembleDebug --no-daemon --stacktrace
          mkdir -p "$GITHUB_WORKSPACE/saida"
          cp app/build/outputs/apk/debug/app-debug.apk "$GITHUB_WORKSPACE/saida/Bussola.apk"

      - name: Guardar o APK (aba Actions, em Artifacts)
        uses: actions/upload-artifact@v4
        with:
          name: Bussola-APK
          path: saida/Bussola.apk
          if-no-files-found: error

      - name: Publicar em Releases (mais facil de baixar no celular)
        continue-on-error: true
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          gh release create "apk-${{ github.run_number }}" saida/Bussola.apk \
            --title "Bussola (compilacao ${{ github.run_number }})" \
            --notes "APK de teste, assinado com chave de depuracao."
```

Se a execução ficar vermelha, abra-a, toque no passo marcado com ✗ e copie as últimas linhas do erro. Erros de compilação costumam ser pequenos de corrigir.

#### A2. Enviando as pastas (mais prático no computador)

1. Crie uma conta em [github.com](https://github.com) e um repositório novo (pode ser privado).
2. Envie o conteúdo desta pasta, mantendo a estrutura: `.github`, `android` e `web` precisam ficar na raiz do repositório. No site, use **Add file → Upload files** e arraste as três pastas. Isso funciona bem num computador; no celular o envio de pastas é trabalhoso.
   Alguns sistemas escondem pastas que começam com ponto. Se a `.github` não aparecer no repositório, use **Add file → Create new file**, digite o nome `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo de mesmo nome.
3. Abra a aba **Actions**, escolha **Gerar APK** e toque em **Run workflow**. Na primeira vez o GitHub pode pedir para habilitar os workflows.
4. Em uns 5 minutos a execução fica verde. Abra-a e baixe **Bussola-APK** na seção *Artifacts*. É um `.zip` com o `app-debug.apk` dentro.

### Opção B: Android Studio

1. Abra a pasta `android/` no Android Studio e espere o Gradle sincronizar.
2. Escolha **Build → Build APK(s)**.
3. O arquivo fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

### Opção C: com o Antigravity (ou outro agente de IA) no seu computador

Abra a pasta do projeto no Antigravity e peça: *"Siga o arquivo INSTRUCOES-ANTIGRAVITY.md e gere o APK."* Ele confere o JDK e o Android SDK, instala o que faltar, compila e corrige erros pequenos de compilação que apareçam. No fim, ele informa onde ficou o `app-debug.apk`.

### Opção D: linha de comando

Com JDK 17 e o Android SDK 34 instalados (e `ANDROID_HOME` apontando para ele, ou `sdk.dir=...` em `android/local.properties`):

```
cd android
./gradlew assembleDebug
```

## 3. Instalar no A32

1. Passe o APK para o celular (Google Drive, USB, e-mail…).
2. Toque no arquivo. Se o Android pedir, permita **Instalar apps desconhecidos** para o aplicativo que você usou para abri-lo (Arquivos, Chrome…).
3. O Play Protect pode avisar que o app não é conhecido. É esperado: o APK de teste é assinado com uma chave de depuração. Toque em **Instalar mesmo assim**.
4. Para abrir os links do celular na Bússola: **Configurações → Apps → Apps padrão → App de navegador → Bússola**.

## Como o projeto funciona por dentro

No app Android há uma WebView transparente com a interface (`web/`), por cima de uma WebView por aba, que carrega o site de verdade. Só as áreas desenhadas pela interface (barra, menus, folhas) recebem toque; o resto passa direto para o site.

- Interface → Android: `BussolaNative.post('{"cmd":"load","id":3,"url":"https://…"}')`.
- Android → interface: `window.Bussola.onNative({ev:"title",id:3,title:"…"})`.

A lista completa de comandos e eventos está em `web/js/engine.js` (lado da interface) e em `android/app/src/main/java/br/bussola/browser/` (lado Android: `Bridge.java`, `MainActivity.java` e `PageManager.java`). O modo leitura é o script `android/app/src/main/assets/native/reader.js`.

```
.
├── web/                          interface (HTML, CSS, JS, ícones, fonte Inter)
│   ├── index.html
│   ├── css/  base.css  browser.css  sheets.css  font.css
│   ├── js/   engine.js (ponte com o Android)  ui.js  tabs.js  switcher.js  menus.js …
│   ├── manifest.webmanifest  sw.js          (só usados na versão web/PWA)
│   └── icons/  fonts/
├── android/
│   ├── app/src/main/java/br/bussola/browser/
│   │   ├── MainActivity.java     janela, toques, barras do sistema, permissões
│   │   ├── PageManager.java      uma WebView por aba, leitor, downloads, bloqueador
│   │   ├── Bridge.java  Js.java  ponte JavaScript
│   │   └── Trackers.java         lista de rastreadores bloqueados
│   ├── app/src/main/assets/native/reader.js
│   ├── app/src/main/res/         ícone, cores, estilos
│   └── gradlew  gradle/          Gradle Wrapper
└── .github/workflows/build-apk.yml
```

## Personalizar

- **Cores, raios e tamanhos da barra:** variáveis no começo de `web/css/base.css`.
- **Mecanismos de busca:** `B.ENGINES` em `web/js/util.js`.
- **Lista de rastreadores:** `android/app/src/main/java/br/bussola/browser/Trackers.java`.
- **Nome do app:** `android/app/src/main/res/values/strings.xml`. **Ícone:** arquivos `ic_launcher_*.xml` em `res/drawable`.

## Limitações

- O motor de páginas é o **Chromium (WebView do Android)**, não o WebKit. O que lembra o Safari é a interface e a interatividade, não o motor.
- No app Android o vidro é translúcido, mas **sem desfoque real** do site atrás dele, porque a interface fica numa WebView separada da página. Na versão web o desfoque é real.
- **Abas privadas** não salvam histórico, mas o Android só tem um repositório de cookies por app, então elas compartilham cookies com as abas normais.
- Não há sincronização com iCloud, chaves e senhas da Apple, extensões nem perfis.
- Na versão web não existe bloqueador de rastreadores, a barra não encolhe ao rolar e os sites ficam acima da barra, não por trás dela.
- O APK é de **depuração**: assinado com chave de teste e sem otimização. Serve para uso pessoal, não para a Play Store. Para publicar, gere uma versão `release` assinada com a sua chave.
- O código Android foi escrito e revisado, mas **não pôde ser compilado de verdade no ambiente onde foi criado** (sem o Android SDK). Ele passou por uma compilação de teste contra classes do Android simuladas, sem erros, e o manifesto e os recursos foram conferidos. Se o GitHub ou o Android Studio apontar um erro de compilação, ele deve ser pequeno de corrigir: guarde a mensagem de erro.

## Licenças

A fonte **Inter** (subconjunto latino, em `web/fonts/`) é distribuída sob a SIL Open Font License 1.1: <https://openfontlicense.org>.

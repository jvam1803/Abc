const V = 'bussola-v2';
const ASSETS = ['./', 'index.html', 'manifest.webmanifest', 'css/font.css', 'css/base.css', 'css/browser.css', 'css/sheets.css',
  'js/util.js', 'js/store.js', 'js/engine.js', 'js/tabs.js', 'js/ui.js', 'js/chrome.js', 'js/omni.js', 'js/start.js',
  'js/switcher.js', 'js/lists.js', 'js/menus.js', 'js/settings.js', 'js/main.js', 'icons/icon-192.png', 'icons/icon-512.png',
  'fonts/inter-400.woff', 'fonts/inter-500.woff', 'fonts/inter-600.woff', 'fonts/inter-700.woff'];
self.addEventListener('install', e => e.waitUntil(caches.open(V).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});

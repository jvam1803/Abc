(function () {
  'use strict';
  // Camada que fala com o motor de páginas:
  //  - no app Android: WebViews nativas, via ponte BussolaNative;
  //  - no navegador comum (PWA): iframes (muitos sites bloqueiam isso).
  const B = window.B, N = window.BussolaNative;
  const E = B.engine = { native: !!N, canFind: !!N, canReader: !!N, canClear: !!N, canBlock: !!N };
  const pend = {};
  let seq = 0;
  const emit = ev => { if (B.tabs) B.tabs.onEngine(ev); };

  if (N) {
    const post = o => { try { N.post(JSON.stringify(o)); } catch (e) { console.warn('ponte', e); } };
    E.create = t => post({ cmd: 'create', id: t.id, url: t.url || '', desktop: !!t.desktop, zoom: t.zoom || 100, priv: !!t.priv });
    E.show = id => post({ cmd: 'show', id: id || '' });
    E.load = (id, url) => post({ cmd: 'load', id, url });
    E.back = id => post({ cmd: 'back', id });
    E.forward = id => post({ cmd: 'forward', id });
    E.reload = id => post({ cmd: 'reload', id });
    E.stop = id => post({ cmd: 'stop', id });
    E.destroy = id => post({ cmd: 'destroy', id });
    E.setDesktop = (id, on) => post({ cmd: 'desktop', id, on: !!on });
    E.setZoom = (id, pct) => post({ cmd: 'zoom', id, pct });
    E.find = (id, q) => post({ cmd: 'find', id, q });
    E.findNext = (id, fwd) => post({ cmd: 'findNext', id, fwd: !!fwd });
    E.findClear = id => post({ cmd: 'findClear', id });
    E.reader = (id, on) => post({ cmd: 'reader', id, on: !!on, opts: B.data.settings.reader || { size: 100, theme: 'white', font: 'sans' } });
    E.readerOpts = (id, o) => post({ cmd: 'readerOpts', id, opts: o });
    E.layout = (all, rects, inset) => post({ cmd: 'layout', all: !!all, rects: rects || [], inset: inset || 0 });
    E.share = (url, title) => post({ cmd: 'share', url, title });
    E.copy = text => post({ cmd: 'copy', text });
    E.external = url => post({ cmd: 'external', url });
    E.print = id => post({ cmd: 'print', id });
    E.download = url => post({ cmd: 'download', url });
    E.clear = what => post({ cmd: 'clear', what });
    E.theme = (dark, color, color2) => post({ cmd: 'theme', dark: !!dark, color: color || '', color2: color2 || '' });
    E.settings = s => post({ cmd: 'settings', block: !!s.block });
    E.minimize = () => post({ cmd: 'minimize' });
    E.ready = () => post({ cmd: 'ready' });
    E.snapshot = id => new Promise(res => {
      const k = 's' + id; pend[k] = res; post({ cmd: 'snap', id });
      setTimeout(() => { if (pend[k] === res) { delete pend[k]; res(null); } }, 600);
    });
    E.fetchSuggest = url => new Promise(res => {
      const n = ++seq, k = 'g' + n; pend[k] = res; post({ cmd: 'suggest', n, url });
      setTimeout(() => { if (pend[k] === res) { delete pend[k]; res([]); } }, 2500);
    });
    window.Bussola = {
      onNative(ev) {
        if (ev.ev === 'snap') { const k = 's' + ev.id, f = pend[k]; if (f) { delete pend[k]; f(ev.data || null); } return; }
        if (ev.ev === 'suggest') { const k = 'g' + ev.n, f = pend[k]; if (f) { delete pend[k]; f(ev.list || []); } return; }
        if (ev.ev === 'sys') { B.sysDark = !!ev.dark; if (B.chrome) B.chrome.applyTheme(); return; }
        if (ev.ev === 'back') { if (B.main) B.main.onBack(); return; }
        emit(ev);
      }
    };
  } else {
    const frames = B.$('#frames'), els = {}, st = {};
    // Demonstração (window.BUSSOLA_DEMO): só abrem as páginas de exemplo da própria origem, na pasta demo/.
    const DEMO = !!window.BUSSOLA_DEMO;
    const demoPage = u => { try { const x = new URL(u, location.href); return DEMO && x.origin === location.origin && /\/demo\/[\w-]+\.html$/.test(x.pathname); } catch (e) { return false; } };
    // Sites que proíbem ser exibidos dentro de um iframe (vale só para a versão web).
    const BLOCK = /(^|\.)(google\.[a-z.]+|youtube\.com|facebook\.com|instagram\.com|x\.com|twitter\.com|linkedin\.com|github\.com|whatsapp\.com|netflix\.com|amazon\.[a-z.]+|bing\.com|duckduckgo\.com|reddit\.com|tiktok\.com|twitch\.tv|spotify\.com|paypal\.com|live\.com|outlook\.com|yahoo\.com|globo\.com|mercadolivre\.com\.br|ecosia\.org|brave\.com)$/i;
    const cur = id => { const s = st[id]; return (s && s.list[s.i]) || ''; };
    const nav = id => { const s = st[id]; emit({ ev: 'url', id, url: cur(id), canBack: s.i > 0, canFwd: s.i < s.list.length - 1 }); };

    function go(id, url, push) {
      const f = els[id], s = st[id]; if (!f) return;
      if (push) { s.list.splice(s.i + 1); s.list.push(url); s.i++; }
      emit({ ev: 'start', id, url });
      nav(id);
      clearInterval(f._p);
      const demo = demoPage(url);
      f.classList.toggle('full', demo);
      let same = false; try { same = new URL(url).origin === location.origin; } catch (e) { same = true; }
      if (!demo && (same || DEMO || BLOCK.test(B.host(url)) || !/^https?:/i.test(url))) {
        f.removeAttribute('src');
        emit({ ev: 'progress', id, p: 100 });
        emit({ ev: 'error', id, url, code: 'frame', desc: DEMO
          ? 'Na demonstração, os sites da internet não abrem aqui dentro. No app Android eles abrem normalmente.'
          : 'Este site não permite ser exibido dentro da versão web. No app Android ele abre normalmente.' });
        return;
      }
      let p = 10; emit({ ev: 'progress', id, p });
      f._p = setInterval(() => { p = Math.min(90, p + (90 - p) * 0.18); emit({ ev: 'progress', id, p: Math.round(p) }); }, 160);
      f.src = url;
    }

    // Páginas da mesma origem (os exemplos da demonstração) podem ser lidas: título, endereço e rolagem.
    function peek(id, f) {
      const out = { url: '', title: '' };
      try {
        const w = f.contentWindow, d = f.contentDocument, href = w.location.href;
        if (!d || !href || href === 'about:blank') return out;
        out.title = d.title || ''; out.url = href;
        const s = st[id];
        if (s && href !== cur(id)) { s.list.splice(s.i + 1); s.list.push(href); s.i++; nav(id); }
        emit({ ev: 'scroll', id, dir: 'up' });   // página nova começa no topo: a barra volta ao tamanho normal
        if (!w.__bsScroll) {
          w.__bsScroll = true; let last = 0;
          w.addEventListener('scroll', () => {
            const y = w.pageYOffset || 0, dy = y - last;
            if (y <= 0) { last = 0; emit({ ev: 'scroll', id, dir: 'up' }); return; }
            if (Math.abs(dy) < 10) return;
            last = y; emit({ ev: 'scroll', id, dir: dy > 0 ? 'down' : 'up' });
          }, { passive: true });
        }
      } catch (e) { /* outra origem: não dá para ler */ }
      return out;
    }

    E.create = t => {
      const f = B.h('iframe', { class: 'pf', title: 'Página', allow: 'fullscreen; autoplay; clipboard-write', sandbox: 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals allow-presentation' });
      f.hidden = true; frames.append(f); els[t.id] = f; st[t.id] = { list: [], i: -1 };
      f.addEventListener('load', () => {
        if (!f.getAttribute('src')) return;
        clearInterval(f._p);
        const info = peek(t.id, f);
        emit({ ev: 'progress', id: t.id, p: 100 });
        emit({ ev: 'finish', id: t.id, url: info.url || cur(t.id), title: info.title });
      });
      if (t.url) go(t.id, t.url, true);
    };
    E.show = id => { for (const k in els) els[k].hidden = (k !== id); };
    E.load = (id, url) => go(id, url, true);
    E.back = id => { const s = st[id]; if (s && s.i > 0) { s.i--; go(id, s.list[s.i], false); } };
    E.forward = id => { const s = st[id]; if (s && s.i < s.list.length - 1) { s.i++; go(id, s.list[s.i], false); } };
    E.reload = id => { const u = cur(id); if (u) go(id, u, false); };
    E.stop = id => {
      const f = els[id]; if (!f) return;
      clearInterval(f._p);
      try { f.contentWindow.stop(); } catch (e) { /* outra origem */ }
      emit({ ev: 'progress', id, p: 100 }); emit({ ev: 'finish', id, url: cur(id), title: '' });
    };
    E.destroy = id => { if (els[id]) { clearInterval(els[id]._p); els[id].remove(); delete els[id]; delete st[id]; } };
    E.setDesktop = id => E.reload(id);
    E.setZoom = () => {}; E.find = () => {}; E.findNext = () => {}; E.findClear = () => {};
    E.reader = () => {}; E.readerOpts = () => {}; E.layout = () => {}; E.print = () => window.print();
    E.snapshot = () => Promise.resolve(null);
    E.settings = () => {}; E.clear = () => {}; E.minimize = () => {}; E.ready = () => {};
    E.theme = (dark, color) => { const m = B.$('meta[name=theme-color]'); if (m && color) m.setAttribute('content', color); };
    E.share = (url, title) => {
      if (navigator.share) navigator.share({ title: title || '', url }).catch(() => {});
      else E.copy(url);
    };
    E.copy = text => {
      if (navigator.clipboard) navigator.clipboard.writeText(text).catch(() => {});
      else { const a = B.h('textarea', { style: 'position:fixed;opacity:0' }); a.value = text; document.body.append(a); a.select(); try { document.execCommand('copy'); } catch (e) { /* sem cópia */ } a.remove(); }
    };
    E.external = url => {
      // Um link comum abre em nova aba também dentro de molduras restritas, onde window.open pode falhar.
      try { const a = document.createElement('a'); a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.style.display = 'none'; document.body.append(a); a.click(); a.remove(); }
      catch (e) { window.open(url, '_blank', 'noopener'); }
    };
    E.download = url => window.open(url, '_blank', 'noopener');
    E.fetchSuggest = url => fetch(url).then(r => r.json()).then(j => (j[1] || []).slice(0, 6)).catch(() => []);
  }

  E.suggest = function (q) {
    const eng = B.ENGINES[B.data.settings.engine] || B.ENGINES.google;
    if (!eng.sug || !B.data.settings.suggest) return Promise.resolve([]);
    return E.fetchSuggest(eng.sug.replace('%s', encodeURIComponent(q)));
  };
})();

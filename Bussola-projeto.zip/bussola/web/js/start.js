(function () {
  'use strict';
  // Página inicial (favoritos, relatório de privacidade, leitura) e tela de erro.
  const B = window.B, { $, h } = B, E = B.engine, T = B.tabs, U = B.ui;
  const S = B.start = {};
  let key = '', rev = 0;

  S.invalidate = function () {
    rev++;
    const t = T.cur();
    if (t && !$('#start').hidden) S.sync(t);
  };

  S.sync = function (t) {
    const st = $('#start'), bl = $('#blocked');
    const showStart = !t.url && !t.error, showErr = !!t.error;
    if (showStart) {
      const k = [t.id, t.priv, rev, JSON.stringify(B.data.settings), B.data.favorites.length].join('|');
      if (k !== key || st.hidden) { key = k; renderStart(st, t); }
    }
    if (showErr) renderError(bl, t);
    if (st.hidden === showStart) { st.hidden = !showStart; if (showStart) st.scrollTop = 0; }
    bl.hidden = !showErr;
  };

  const sec = (title, node, more) => h('div', { class: 'st-sec' },
    h('div', { class: 'st-h' }, h('span', { text: title }), more || null), node);

  function openUrl(url, how) {
    const cur = T.cur();
    if (how === 'new') T.create({ url, parent: cur.id });
    else if (how === 'priv') T.create({ url, priv: true });
    else T.navigate(cur, url);
  }

  function renderStart(el, t) {
    el.innerHTML = '';
    const wrap = h('div', { class: 'st-wrap' });
    el.append(wrap);
    if (t.priv) {
      wrap.append(h('div', { class: 'st-priv' }, B.icon('incog', 'big'),
        h('h2', { text: 'Navegação Privada' }),
        h('p', { text: 'As abas privadas não salvam o histórico, as pesquisas recentes nem os dados de preenchimento.' }),
        E.native ? h('p', { class: 'fine', text: 'Observação: o Android compartilha cookies e logins com as abas normais.' }) : null));
      return;
    }
    const s = B.data.settings;
    if (s.secFav) {
      const grid = h('div', { class: 'st-grid' });
      B.data.favorites.forEach(f => {
        const b = h('button', { class: 'st-fav press', onclick: () => openUrl(f.url) }, B.tile(f.url, f.title, 62), h('span', { text: f.title }));
        B.longPress(b, () => U.menu(b, [
          { label: 'Abrir em Nova Aba', icon: 'plus', run: () => openUrl(f.url, 'new') },
          { label: 'Abrir em Aba Privada', icon: 'incog', run: () => openUrl(f.url, 'priv') },
          { label: 'Copiar Link', icon: 'copy', run: () => { E.copy(f.url); U.toast('Link copiado'); } },
          { sep: true },
          { label: 'Remover', icon: 'trash', danger: true, run: () => { B.fav.remove(f.url); S.invalidate(); } }
        ]));
        grid.append(b);
      });
      if (!B.data.favorites.length) grid.append(h('div', { class: 'st-empty', text: 'Adicione sites pelo botão Compartilhar.' }));
      wrap.append(sec('Favoritos', grid));
    }
    if (s.secPriv && E.canBlock) {
      const n = B.data.privacy.total;
      wrap.append(sec('Relatório de Privacidade', h('button', { class: 'st-card press', onclick: () => B.lists.privacy() },
        h('div', { class: 'shield' }, B.icon('shield')),
        h('div', { class: 'ctxt' }, h('b', { text: n + ' ' + (n === 1 ? 'rastreador impedido' : 'rastreadores impedidos') }),
          h('span', { text: 'Sites que tentaram acompanhar você foram bloqueados.' })))));
    }
    if (s.secRead) {
      const un = B.data.reading.filter(r => !r.read).slice(0, 3);
      if (un.length) wrap.append(sec('Lista de Leitura', h('div', { class: 'st-list' }, un.map(r =>
        h('button', { class: 'st-row press', onclick: () => openUrl(r.url) }, B.tile(r.url, r.title, 40),
          h('div', { class: 'ctxt' }, h('b', { text: r.title }), h('span', { text: B.host(r.url) }))))),
        h('button', { class: 'st-more', text: 'Ver tudo', onclick: () => B.lists.open('reading') })));
    }
    if (s.secFreq) {
      const fq = B.hist.frequent(6);
      if (fq.length) wrap.append(sec('Visitados com frequência', h('div', { class: 'st-grid' }, fq.map(f =>
        h('button', { class: 'st-fav press', onclick: () => openUrl(f.url) }, B.tile(f.url, f.title, 62), h('span', { text: f.host }))))));
    }
    wrap.append(h('button', { class: 'st-edit press', onclick: () => B.settings.open() }, B.icon('gear', 'sm'), 'Ajustes'));
  }

  function renderError(el, t) {
    const e = t.error, k = 'e|' + t.id + '|' + e.code + '|' + e.url;
    if (el._k === k) return; el._k = k; el.innerHTML = '';
    const ssl = e.code === 'ssl', off = e.code === 'offline';
    const title = ssl ? 'Esta conexão não é segura' : off ? 'Sem conexão com a internet' : e.code === 'frame' ? 'Disponível só no app Android' : 'Não foi possível abrir a página';
    el.append(h('div', { class: 'err' }, B.icon(ssl ? 'shield' : off ? 'globe' : 'minus', 'big'),
      h('h2', { text: title }),
      h('p', { text: e.desc || 'Verifique o endereço e tente novamente.' }),
      h('p', { class: 'fine', text: B.host(e.url) || e.url }),
      h('div', { class: 'err-btns' },
        e.code === 'frame' ? null : h('button', { class: 'btn', text: 'Tentar novamente', onclick: () => T.navigate(t, e.url) }),
        h('button', { class: 'btn alt', text: 'Abrir no navegador do sistema', onclick: () => E.external(e.url) }))));
  }
})();

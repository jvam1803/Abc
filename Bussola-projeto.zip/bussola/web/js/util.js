(function () {
  'use strict';
  const B = window.B = window.B || {};
  const NS = 'http://www.w3.org/2000/svg';

  B.$ = (s, r) => (r || document).querySelector(s);
  B.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  B.h = function (tag, attrs, ...kids) {
    const e = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(2)) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
    return e;
  };

  B.icon = function (name, cls) {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('class', 'ic' + (cls ? ' ' + cls : ''));
    const u = document.createElementNS(NS, 'use');
    u.setAttribute('href', '#i-' + name);
    s.append(u);
    return s;
  };

  B.uid = () => Date.now().toString(36).slice(-4) + Math.random().toString(36).slice(2, 7);
  B.debounce = (fn, ms) => { let t; return function () { const a = arguments, c = this; clearTimeout(t); t = setTimeout(() => fn.apply(c, a), ms); }; };
  B.vibe = ms => { try { navigator.vibrate && navigator.vibrate(ms || 8); } catch (e) { /* sem vibração */ } };
  B.raf2 = fn => requestAnimationFrame(() => requestAnimationFrame(fn));

  B.ENGINES = {
    google: { name: 'Google', url: 'https://www.google.com/search?q=%s', sug: 'https://suggestqueries.google.com/complete/search?client=firefox&q=%s' },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=%s', sug: 'https://duckduckgo.com/ac/?type=list&q=%s' },
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=%s', sug: 'https://api.bing.com/osjson.aspx?query=%s' },
    brave: { name: 'Brave Search', url: 'https://search.brave.com/search?q=%s', sug: null },
    ecosia: { name: 'Ecosia', url: 'https://www.ecosia.org/search?q=%s', sug: null },
    wikipedia: { name: 'Wikipédia', url: 'https://pt.wikipedia.org/w/index.php?search=%s', sug: 'https://pt.wikipedia.org/w/api.php?action=opensearch&format=json&origin=*&limit=6&search=%s' }
  };
  B.searchUrl = (q, key) => (B.ENGINES[key] || B.ENGINES.google).url.replace('%s', encodeURIComponent(q));

  // Interpreta o que foi digitado: endereço ou pesquisa.
  B.parseInput = function (raw) {
    const s = (raw || '').trim();
    if (!s || /^javascript:/i.test(s)) return null;
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s) || /^(about|data|view-source):/i.test(s)) return { url: s, search: false };
    if (!/\s/.test(s)) {
      if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?([/?#].*)?$/i.test(s)) return { url: 'http://' + s, search: false };
      if (/^([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(s)) return { url: 'https://' + s, search: false };
    }
    return { url: B.searchUrl(s, B.data.settings.engine), search: true, q: s };
  };

  // Na demonstração, as páginas de exemplo (mesma origem) aparecem com um endereço próprio.
  B.host = u => { try { const x = new URL(u); if (window.BUSSOLA_DEMO && x.origin === location.origin) return 'exemplo.bussola'; return x.hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
  B.isHttps = u => /^https:/i.test(u || '');
  // Só tons de cinza: cada site ganha um degradê diferente, sempre neutro.
  const PAL = [['#8a8a8a', '#5c5c5c'], ['#767676', '#474747'], ['#979797', '#686868'], ['#6c6c6c', '#3d3d3d'],
    ['#838383', '#555555'], ['#a0a0a0', '#727272'], ['#727272', '#424242'], ['#909090', '#616161']];
  B.color = s => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; const p = PAL[h % PAL.length]; return 'linear-gradient(160deg,' + p[0] + ',' + p[1] + ')'; };

  // Ícone quadrado de um site: favicon salvo ou letra colorida.
  B.tile = function (url, title, size) {
    const host = B.host(url) || title || '?';
    const el = B.h('div', { class: 'tile', style: 'background:' + B.color(host) });
    const ico = B.icons && B.icons.get(host);
    if (ico) { el.classList.add('ico'); el.append(B.h('img', { src: ico, alt: '' })); }
    else el.textContent = (title || host).charAt(0).toUpperCase();
    if (size) { el.style.width = el.style.height = size + 'px'; el.style.fontSize = Math.round(size * 0.44) + 'px'; el.style.borderRadius = Math.round(size * 0.27) + 'px'; }
    return el;
  };

  B.dayLabel = ts => {
    const d = new Date(ts), n = new Date();
    const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diff = Math.round((day(n) - day(d)) / 864e5);
    if (diff === 0) return 'Hoje';
    if (diff === 1) return 'Ontem';
    const s = d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    return s.charAt(0).toUpperCase() + s.slice(1);
  };
  B.hhmm = ts => new Date(ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  // Toque longo: dispara cb e engole o clique seguinte.
  B.longPress = function (el, cb, ms) {
    let t = null, sx = 0, sy = 0, fired = false;
    const cancel = () => clearTimeout(t);
    el.addEventListener('pointerdown', e => {
      fired = false; sx = e.clientX; sy = e.clientY; cancel();
      t = setTimeout(() => { fired = true; B.vibe(14); cb(e); }, ms || 430);
    });
    el.addEventListener('pointermove', e => { if (Math.abs(e.clientX - sx) > 9 || Math.abs(e.clientY - sy) > 9) cancel(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(n => el.addEventListener(n, cancel));
    el.addEventListener('click', e => { if (fired) { e.stopPropagation(); e.preventDefault(); fired = false; } }, true);
    el.addEventListener('contextmenu', e => e.preventDefault());
  };
})();

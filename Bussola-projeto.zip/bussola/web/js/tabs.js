(function () {
  'use strict';
  const B = window.B, E = B.engine;
  const T = B.tabs = { list: [], active: null, mode: 'normal', thumbs: {} };

  const mk = () => ({
    id: B.uid(), url: '', title: '', priv: false, desktop: false, zoom: 100, loading: false, progress: 0,
    canBack: false, canFwd: false, created: false, lastActive: Date.now(), parent: null,
    readable: false, reader: false, secure: false, error: null, blocked: 0
  });

  T.byId = id => T.list.find(t => t.id === id) || null;
  T.cur = () => T.byId(T.active);
  T.inMode = p => T.list.filter(t => !!t.priv === !!p);
  T.title = t => t.title || B.host(t.url) || t.url || (t.priv ? 'Navegação Privada' : 'Página Inicial');

  const saveThumbs = B.debounce(() => {
    const keep = {};
    T.list.forEach(t => { if (!t.priv && T.thumbs[t.id]) keep[t.id] = T.thumbs[t.id]; });
    B.lsSet('bs.thumbs', JSON.stringify(keep));
  }, 1200);

  T.persist = B.debounce(() => {
    const c = T.cur();
    B.data.tabs = {
      list: T.list.filter(t => !t.priv).map(t => ({ id: t.id, url: t.url, title: t.title, desktop: t.desktop, zoom: t.zoom, lastActive: t.lastActive, parent: t.parent })),
      active: c && !c.priv ? c.id : B.data.tabs.active
    };
    B.save('tabs');
  }, 400);

  T.restore = function () {
    const s = B.data.tabs || { list: [] };
    const spans = { day: 864e5, week: 6048e5, month: 2592e6 };
    const keep = spans[B.data.settings.autoClose] || 0;
    T.list = (s.list || []).filter(t => !keep || Date.now() - (t.lastActive || 0) < keep)
      .map(o => Object.assign(mk(), o, { created: false, loading: false, progress: 0, secure: B.isHttps(o.url) }));
    try { T.thumbs = JSON.parse(B.lsGet('bs.thumbs') || '{}'); } catch (e) { T.thumbs = {}; }
    if (!T.list.length) { T.create(); return; }
    T.select(T.byId(s.active) ? s.active : T.list[0].id);
  };

  T.create = function (o) {
    o = o || {};
    const t = mk();
    if (o.id) t.id = o.id;
    t.priv = !!o.priv; t.parent = o.parent || null; t.created = !!o.created;
    t.desktop = !!B.data.settings.desktop;
    const pi = t.parent ? T.list.findIndex(x => x.id === t.parent) : -1;
    if (pi >= 0) T.list.splice(pi + 1, 0, t); else T.list.push(t);
    if (o.url) T.navigate(t, o.url);
    if (o.bg) T.changed(t); else T.select(t.id);
    return t;
  };

  T.navigate = function (t, url) {
    t.error = null; t.url = url; t.title = ''; t.loading = true; t.progress = 6;
    t.reader = false; t.readable = false; t.secure = B.isHttps(url); t.blocked = 0;
    if (t.created) E.load(t.id, url);
    else { t.created = true; E.create(t); }
    if (t.id === T.active) E.show(t.id);
    T.changed(t);
  };

  T.select = function (id) {
    const t = T.byId(id); if (!t) return;
    const prev = T.cur();
    if (prev && prev.id !== id) T.capture(prev);
    T.active = id; t.lastActive = Date.now(); T.mode = t.priv ? 'private' : 'normal';
    if (t.url) { if (!t.created) { t.created = true; E.create(t); } E.show(t.id); }
    else E.show('');
    if (B.chrome) B.chrome.refresh();
    T.persist();
  };

  T.close = function (id) {
    const i = T.list.findIndex(t => t.id === id); if (i < 0) return;
    const t = T.list[i], wasActive = T.active === id;
    E.destroy(id); T.list.splice(i, 1); delete T.thumbs[id]; saveThumbs();
    if (wasActive) {
      const same = T.inMode(t.priv);
      let nx = (t.parent && T.byId(t.parent)) || same.find(x => T.list.indexOf(x) >= i) || same[same.length - 1] || null;
      if (!nx) nx = T.list.filter(x => !x.priv).sort((a, b) => b.lastActive - a.lastActive)[0] || null;
      if (!nx) nx = T.create({ bg: true });
      T.select(nx.id);
    } else T.persist();
  };
  T.closeOthers = id => T.inMode(T.byId(id).priv).filter(t => t.id !== id).forEach(t => T.close(t.id));
  T.closeAll = priv => {
    const ids = T.inMode(priv).map(t => t.id);
    ids.forEach(i => { E.destroy(i); delete T.thumbs[i]; });
    T.list = T.list.filter(t => !ids.includes(t.id));
    let nx = T.list.filter(x => !x.priv).sort((a, b) => b.lastActive - a.lastActive)[0];
    if (!nx) nx = T.create({ bg: true });
    T.select(nx.id); saveThumbs();
  };

  T.capture = function (t) {
    if (!t || !t.url || !E.native || t.priv) return Promise.resolve();
    return E.snapshot(t.id).then(d => {
      if (!d) return;
      T.thumbs[t.id] = d; saveThumbs();
      if (B.switcher) B.switcher.thumb(t.id);
    });
  };

  T.changed = function (t) {
    if (t.id === T.active && B.chrome) B.chrome.refresh();
    if (B.switcher) B.switcher.update(t);
    T.persist();
  };

  T.back = function () {
    const t = T.cur(); if (!t) return false;
    if (t.canBack) { E.back(t.id); return true; }
    return false;
  };

  T.onEngine = function (ev) {
    if (ev.ev === 'download') { B.dl.add(ev.name, ev.url); B.ui.toast('Baixando “' + ev.name + '”…'); if (B.lists) B.lists.refreshIfOpen('downloads'); return; }
    if (ev.ev === 'popup') {
      const par = T.byId(ev.parent);
      const nt = T.create({ id: ev.id, parent: ev.parent, created: true, priv: !!(par && par.priv), bg: !!ev.bg });
      nt.loading = true; if (!ev.bg) E.show(ev.id);
      return;
    }
    if (ev.ev === 'find') { if (B.menus) B.menus.onFind(ev.active, ev.total); return; }
    if (ev.ev === 'open') { const c = T.cur(); if (c && !c.url && !c.priv) T.navigate(c, ev.url); else T.create({ url: ev.url }); return; }
    if (ev.ev === 'ctx') { if (B.menus) B.menus.linkMenu(ev); return; }
    if (ev.ev === 'toast') { B.ui.toast(ev.msg); return; }
    if (ev.ev === 'close') { T.close(ev.id); return; }
    const t = T.byId(ev.id); if (!t) return;
    switch (ev.ev) {
      case 'start':
        t.url = ev.url; t.loading = true; t.progress = Math.max(t.progress, 6); t.secure = B.isHttps(ev.url);
        t.error = null; t.reader = false; t.readable = false; t.blocked = 0;
        if (t.id === T.active) E.show(t.id);
        break;
      case 'progress': t.progress = ev.p; if (ev.p < 100) t.loading = true; break;
      case 'url': {
        const was = t.url; t.url = ev.url; t.canBack = !!ev.canBack; t.canFwd = !!ev.canFwd; t.secure = B.isHttps(ev.url);
        if (!t.loading && was !== ev.url && !t.priv) B.hist.add(ev.url, t.title);
        break;
      }
      case 'title': t.title = ev.title || ''; if (!t.priv) B.hist.setTitle(t.url, t.title); break;
      case 'finish':
        t.loading = false; t.progress = 100;
        if (ev.url) t.url = ev.url;
        if (ev.title) t.title = ev.title;
        if (!t.priv) B.hist.add(t.url, t.title);
        if (t.id === T.active && !t.priv) setTimeout(() => { if (T.active === t.id) T.capture(t); }, 700);
        break;
      case 'icon': B.icons.set(B.host(t.url), ev.data); if (B.start) B.start.invalidate(); break;
      case 'readable': t.readable = !!ev.on; break;
      case 'reader': t.reader = !!ev.on; break;
      case 'scroll': if (t.id === T.active && B.chrome) B.chrome.onScroll(ev.dir); return;
      case 'blocked': t.blocked += ev.n || 1; B.priv.hit(ev.host || '?', ev.n || 1); return;
      case 'error': t.loading = false; t.progress = 100; t.error = { code: ev.code, desc: ev.desc, url: ev.url || t.url }; break;
      default: return;
    }
    T.changed(t);
  };
})();

(function () {
  'use strict';
  // Peças de interface compartilhadas: aviso, menu, folha de ações, folha inferior, linha deslizável.
  const B = window.B, { h, $ } = B;
  const U = B.ui = { stack: [], _mt: 0 };

  let tt;
  U.toast = (msg, ms) => {
    const el = $('#toast'); el.textContent = msg; el.classList.add('on');
    clearTimeout(tt); tt = setTimeout(() => el.classList.remove('on'), ms || 1900);
  };

  // Pilha de camadas abertas (a tecla "voltar" fecha a de cima).
  U.push = (name, close) => { U.stack.push({ name, close }); B.layout.sync(); };
  U.pop = name => {
    const i = U.stack.map(s => s.name).lastIndexOf(name);
    if (i >= 0) U.stack.splice(i, 1);
    B.layout.sync();
  };
  U.closeTop = () => { const s = U.stack[U.stack.length - 1]; if (!s) return false; s.close(); return true; };
  U.isOpen = name => U.stack.some(s => s.name === name);

  const cssN = n => parseInt(getComputedStyle(document.documentElement).getPropertyValue(n), 10) || 0;
  // A página ocupa a tela toda e a barra flutua por cima. Aqui o app nativo recebe: se a interface
  // está cobrindo tudo, as áreas onde os toques vão para a interface e a altura da barra expandida
  // (usada como folga no fim das páginas).
  B.layout = {
    sync: B.debounce(function () {
      const compact = $('#app').classList.contains('compact');
      let bar = compact ? cssN('--dock-c') : cssN('--dock-h');
      if (!$('#findbar').hidden) bar += cssN('--h-find') + cssN('--g');
      const shown = !$('#start').hidden || !$('#blocked').hidden;
      const W = innerWidth, H = innerHeight;
      document.documentElement.style.setProperty('--chrome-h', bar + 'px');
      B.engine.layout(U.stack.length > 0 || shown, [[0, Math.max(0, H - bar), W, H]], cssN('--dock-h'));
    }, 10)
  };

  function layerOpen() { const L = $('#menu-layer'); U._mt++; L.hidden = false; L.innerHTML = ''; L.classList.remove('out'); return L; }
  function layerClose(L, token) {
    L.classList.add('out');
    setTimeout(() => { if (U._mt === token) { L.hidden = true; L.innerHTML = ''; L.classList.remove('out'); } }, 190);
    U.pop('menu');
  }

  // Menu flutuante junto a um elemento. items: {label, icon, checked, danger, disabled, sep, node, run}
  U.menu = function (anchor, items, opts) {
    opts = opts || {};
    const L = layerOpen(), token = U._mt; let closed = false;
    const close = () => { if (closed) return; closed = true; layerClose(L, token); };
    const box = h('div', { class: 'menu' });
    items.forEach(it => {
      if (!it) return;
      if (it.node) box.append(it.node);
      else if (it.sep) box.append(h('div', { class: 'msep' }));
      else box.append(h('button', {
        class: 'mi' + (it.danger ? ' danger' : '') + (it.disabled ? ' dis' : ''),
        onclick: () => { if (it.disabled) return; close(); if (it.run) setTimeout(it.run, 50); }
      }, h('span', { text: it.label }), it.checked ? B.icon('check', 'sm') : (it.icon ? B.icon(it.icon, 'sm') : null)));
    });
    L.append(h('div', { class: 'scrim clear', onclick: close }), box);
    const r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : { left: innerWidth / 2, right: innerWidth / 2, top: innerHeight / 2, bottom: innerHeight / 2 };
    const w = Math.min(opts.width || 272, innerWidth - 24), cx = (r.left + r.right) / 2;
    const left = Math.max(12, Math.min(innerWidth - w - 12, cx - w / 2));
    const above = r.top > innerHeight * 0.45;
    box.style.width = w + 'px'; box.style.left = left + 'px';
    box.style.maxHeight = Math.round(innerHeight * 0.7) + 'px';
    if (above) { box.style.bottom = (innerHeight - r.top + 10) + 'px'; box.style.transformOrigin = (cx - left) + 'px 100%'; }
    else { box.style.top = (r.bottom + 8) + 'px'; box.style.transformOrigin = (cx - left) + 'px 0'; }
    U.push('menu', close);
    return { close };
  };

  // Folha de ações vinda de baixo (estilo iOS). list: {label, danger, checked, run}
  U.actions = function (title, list, cancel) {
    const L = layerOpen(), token = U._mt; let closed = false;
    const close = () => { if (closed) return; closed = true; layerClose(L, token); };
    const grp = h('div', { class: 'ag' }, title ? h('div', { class: 'at', text: title }) : null,
      list.map(a => h('button', { class: 'ab' + (a.danger ? ' danger' : ''), onclick: () => { close(); if (a.run) setTimeout(a.run, 60); } },
        h('span', { text: a.label }), a.checked ? B.icon('check', 'sm') : null)));
    L.append(h('div', { class: 'scrim', onclick: close }), h('div', { class: 'asheet' }, grp, h('button', { class: 'ab cancel', onclick: close, text: cancel || 'Cancelar' })));
    U.push('menu', close);
  };
  U.confirm = (title, label, run) => U.actions(title, [{ label, danger: true, run }]);

  // Folha inferior (listas, ajustes, compartilhar).
  U.sheet = function (o) {
    const host = $('#sheet');
    if (U.isOpen('sheet')) { host.hidden = true; host.innerHTML = ''; U.pop('sheet'); }
    host.hidden = false; host.innerHTML = '';
    const grab = h('div', { class: 'sh-grab' }, h('i'));
    const body = h('div', { class: 'sh-body scroll' });
    const title = h('div', { class: 'sh-t', text: o.title || '' });
    const head = h('div', { class: 'sh-head' },
      h('div', { class: 'sh-l' }, o.left ? h('button', { class: 'sh-btn', onclick: o.left.run }, o.left.icon ? B.icon(o.left.icon) : o.left.label) : null),
      title, h('div', { class: 'sh-r' }, h('button', { class: 'sh-btn bold', onclick: () => api.close(), text: o.done || 'OK' })));
    const panel = h('div', { class: 'sh-panel' + (o.tall ? ' tall' : '') }, grab, head, body, o.foot || null);
    const scrim = h('div', { class: 'sh-scrim', onclick: () => api.close() });
    host.append(scrim, panel);
    let closing = false;
    const api = {
      body, panel, title,
      close() {
        if (closing) return; closing = true;
        panel.classList.add('out'); scrim.classList.add('out');
        setTimeout(() => { if (host.firstChild === scrim) { host.hidden = true; host.innerHTML = ''; } if (o.onClose) o.onClose(); }, 260);
        U.pop('sheet');
      }
    };
    // arrastar para baixo para fechar
    let sy = 0, dy = 0, t0 = 0;
    const move = e => { dy = Math.max(0, e.clientY - sy); panel.style.transform = 'translateY(' + dy + 'px)'; scrim.style.opacity = String(Math.max(0, 1 - dy / 520)); };
    const up = () => {
      removeEventListener('pointermove', move); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
      panel.style.transition = ''; const v = dy / Math.max(1, performance.now() - t0);
      if (dy > 110 || v > 0.55) { panel.style.transform = ''; scrim.style.opacity = ''; api.close(); }
      else { panel.style.transform = ''; scrim.style.opacity = ''; }
    };
    [grab, title].forEach(el => el.addEventListener('pointerdown', e => {
      sy = e.clientY; dy = 0; t0 = performance.now(); panel.style.transition = 'none';
      addEventListener('pointermove', move); addEventListener('pointerup', up); addEventListener('pointercancel', up);
    }));
    U.push('sheet', () => api.close());
    return api;
  };

  // Linha com "deslizar para excluir". content: elemento da linha.
  U.swipe = function (content, onDelete, label) {
    const W = 88;
    const front = h('div', { class: 'sfront' }, content);
    const back = h('button', { class: 'sback', text: label || 'Excluir', style: 'width:' + W + 'px' });
    const row = h('div', { class: 'swipe' }, back, front);
    let sx = 0, sy = 0, base = 0, dx = 0, lock = null, drag = false, open = false, eat = false;
    const set = x => { front.style.transform = x ? 'translateX(' + x + 'px)' : ''; };
    const kill = () => {
      row.style.height = row.offsetHeight + 'px';
      requestAnimationFrame(() => { row.style.transition = 'height .22s var(--ease), opacity .2s'; row.style.height = '0'; row.style.opacity = '0'; });
      onDelete(); setTimeout(() => row.remove(), 240);
    };
    front.addEventListener('pointerdown', e => { sx = e.clientX; sy = e.clientY; base = open ? -W : 0; lock = null; drag = true; eat = false; front.style.transition = 'none'; });
    front.addEventListener('pointermove', e => {
      if (!drag) return;
      const mx = e.clientX - sx, my = e.clientY - sy;
      if (lock == null && (Math.abs(mx) > 8 || Math.abs(my) > 8)) { lock = Math.abs(mx) > Math.abs(my) ? 'x' : 'y'; if (lock === 'x') front.setPointerCapture(e.pointerId); }
      if (lock !== 'x') return;
      dx = Math.max(-innerWidth, Math.min(0, base + mx)); set(dx);
    });
    const end = () => {
      if (!drag) return; drag = false; front.style.transition = '';
      if (lock !== 'x') return;
      eat = true;
      if (dx < -innerWidth * 0.6) { set(-innerWidth); kill(); }
      else if (dx < -W * 0.5) { open = true; set(-W); }
      else { open = false; set(0); }
    };
    front.addEventListener('pointerup', end); front.addEventListener('pointercancel', end);
    front.addEventListener('click', e => { if (eat) { e.stopPropagation(); e.preventDefault(); eat = false; } else if (open) { e.stopPropagation(); e.preventDefault(); open = false; set(0); } }, true);
    back.addEventListener('click', () => { set(-innerWidth); kill(); });
    return row;
  };
})();

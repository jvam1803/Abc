(function () {
  'use strict';
  // Visão geral de abas: grade de cartões, abrir/fechar com animação, deslizar para fechar.
  const B = window.B, { $, h } = B, E = B.engine, T = B.tabs, U = B.ui;
  const S = B.switcher = { isOpen: false, closing: false, mode: 'normal' };
  let el, grid, segN, segP, built = false;
  const EASE = 'cubic-bezier(.22,.8,.2,1)';

  function build() {
    el = $('#switcher');
    grid = h('div', { class: 'sw-grid scroll' });
    segN = h('button', { class: 'seg', onclick: () => setMode('normal') });
    segP = h('button', { class: 'seg', onclick: () => setMode('private') }, B.icon('incog', 'sm'), 'Privado');
    el.append(grid, h('div', { class: 'sw-bar' },
      h('button', { class: 'sw-plus glass gleam', 'aria-label': 'Nova aba', onclick: newTab }, B.icon('plus')),
      h('div', { class: 'segs glass gleam' }, segN, segP),
      h('button', { class: 'sw-done glass gleam', text: 'OK', onclick: () => S.close() })));
    built = true;
  }

  // Área da página: no app é a tela toda (a barra flutua); na versão web o iframe termina acima da barra.
  const contentRect = () => ({ left: 0, top: 0, width: innerWidth, height: E.native ? innerHeight : innerHeight - (parseInt(getComputedStyle(document.documentElement).getPropertyValue('--chrome-h'), 10) || 0) });
  const rectOf = n => { const r = n.getBoundingClientRect(); return { left: r.left, top: r.top, width: r.width, height: r.height }; };
  const cardEl = id => grid && grid.querySelector('[data-id="' + id + '"]');

  function placeholder(t) {
    if (!t.url) return h('div', { class: 'ph start' }, B.icon(t.priv ? 'incog' : 'globe', 'big'), h('span', { text: t.priv ? 'Navegação Privada' : 'Página Inicial' }));
    return h('div', { class: 'ph' }, B.tile(t.url, T.title(t), 54), h('span', { text: T.title(t) }));
  }
  function fillThumb(box, t) {
    box.innerHTML = '';
    const src = T.thumbs[t.id];
    box.append(src && t.url ? h('img', { src, alt: '', draggable: 'false' }) : placeholder(t));
  }

  function headTile(t) {
    if (t.url) return B.tile(t.url, T.title(t), 18);
    return h('div', { class: 'tile mini' }, B.icon(t.priv ? 'incog' : 'globe', 'sm'));
  }

  function cardFor(t, i) {
    const c = h('div', { class: 'card' + (t.id === T.active ? ' active' : ''), 'data-id': t.id, style: '--i:' + Math.min(i, 8) });
    const head = h('div', { class: 'chead' }, headTile(t), h('span', { class: 'ctitle', text: T.title(t) }),
      h('button', { class: 'cx', 'aria-label': 'Fechar aba', onclick: e => { e.stopPropagation(); removeCard(t.id, 'x'); } }, B.icon('x', 'sm')));
    const thumb = h('div', { class: 'cthumb' }); fillThumb(thumb, t);
    c.append(head, thumb);
    c.addEventListener('click', () => { if (c._moved) { c._moved = false; return; } S.close(t.id); });
    B.longPress(c, () => U.menu(c, [
      { label: 'Fechar Aba', icon: 'x', run: () => removeCard(t.id, 'x') },
      { label: 'Fechar Outras Abas', icon: 'trash', run: () => { T.closeOthers(t.id); render(); } },
      t.url ? { label: 'Copiar Link', icon: 'copy', run: () => { E.copy(t.url); U.toast('Link copiado'); } } : null
    ], { width: 230 }));
    swipeClose(c, t);
    return c;
  }

  function swipeClose(c, t) {
    let sx = 0, sy = 0, dx = 0, lock = null, on = false, t0 = 0;
    c.addEventListener('pointerdown', e => { if (e.target.closest('.cx')) return; sx = e.clientX; sy = e.clientY; dx = 0; lock = null; on = true; t0 = performance.now(); c._moved = false; });
    c.addEventListener('pointermove', e => {
      if (!on) return;
      const mx = e.clientX - sx, my = e.clientY - sy;
      if (lock == null && (Math.abs(mx) > 9 || Math.abs(my) > 9)) { lock = Math.abs(mx) > Math.abs(my) ? 'x' : 'y'; if (lock === 'x') c.setPointerCapture(e.pointerId); }
      if (lock !== 'x') return;
      dx = mx; c.style.transition = 'none';
      c.style.transform = 'translateX(' + dx + 'px) rotate(' + (dx / 45) + 'deg)';
      c.style.opacity = String(1 - Math.min(0.8, Math.abs(dx) / (c.offsetWidth * 1.3)));
    });
    const end = () => {
      if (!on) return; on = false;
      if (lock !== 'x') return;
      c._moved = true;
      const v = Math.abs(dx) / Math.max(1, performance.now() - t0);
      if (Math.abs(dx) > c.offsetWidth * 0.42 || v > 0.7) removeCard(t.id, dx < 0 ? 'l' : 'r');
      else { c.style.transition = 'transform .28s ' + EASE + ', opacity .28s'; c.style.transform = ''; c.style.opacity = ''; }
    };
    c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end);
  }

  // Remove um cartão e reacomoda os outros com animação (FLIP).
  function removeCard(id, how) {
    const c = cardEl(id); if (!c) { T.close(id); return; }
    const x = how === 'l' ? -c.offsetWidth * 1.3 : how === 'r' ? c.offsetWidth * 1.3 : 0;
    c.style.pointerEvents = 'none';
    c.style.transition = 'transform .22s ease-in, opacity .22s ease-in';
    c.style.transform = 'translateX(' + x + 'px) scale(' + (how === 'x' ? 0.82 : 1) + ')'; c.style.opacity = '0';
    B.vibe(8);
    setTimeout(() => {
      const others = Array.from(grid.querySelectorAll('.card')).filter(n => n !== c);
      const first = new Map(others.map(n => [n, rectOf(n)]));
      T.close(id); c.remove();
      const empty = !others.length;
      others.forEach(n => {
        const a = first.get(n), b = rectOf(n), dx = a.left - b.left, dy = a.top - b.top;
        if (dx || dy) n.animate([{ transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' }], { duration: 300, easing: EASE });
      });
      if (empty) render(); else { head(); const act = cardEl(T.active); if (act) act.classList.add('active'); }
    }, 210);
  }

  function head() {
    const n = T.inMode(false).length, p = T.inMode(true).length;
    segN.textContent = n + (n === 1 ? ' aba' : ' abas');
    segN.classList.toggle('on', S.mode === 'normal'); segP.classList.toggle('on', S.mode === 'private');
    segP.title = p ? p + ' privadas' : '';
  }

  function render() {
    grid.innerHTML = '';
    const tabs = T.inMode(S.mode === 'private');
    tabs.forEach((t, i) => grid.append(cardFor(t, i)));
    if (!tabs.length) grid.append(h('div', { class: 'sw-empty' }, B.icon(S.mode === 'private' ? 'incog' : 'tabs', 'big'), h('p', { text: S.mode === 'private' ? 'Nenhuma aba privada aberta.' : 'Nenhuma aba aberta.' })));
    head();
  }
  function setMode(m) {
    if (S.mode === m) return;
    S.mode = m; B.vibe(6);
    grid.animate([{ opacity: 0, transform: 'scale(.97)' }, { opacity: 1, transform: 'none' }], { duration: 240, easing: EASE });
    render();
  }
  function newTab() {
    const t = T.create({ priv: S.mode === 'private' });
    S.close(t.id, true);
  }

  function ghost(t, r, radius) {
    const g = h('div', { class: 'ghost' });
    g.style.cssText = 'left:' + r.left + 'px;top:' + r.top + 'px;width:' + r.width + 'px;height:' + r.height + 'px;border-radius:' + radius + 'px';
    const src = T.thumbs[t.id];
    g.append(src && t.url ? h('img', { src, alt: '' }) : placeholder(t));
    $('#app').append(g);
    return g;
  }
  function fly(g, from, to, r0, r1, ms) {
    const f = r => ({ left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
    return g.animate([Object.assign(f(from), { borderRadius: r0 + 'px' }), Object.assign(f(to), { borderRadius: r1 + 'px' })], { duration: ms, easing: EASE, fill: 'forwards' }).finished.catch(() => {});
  }

  S.open = async function () {
    if (S.isOpen || S.closing) return;
    if (!built) build();
    const cur = T.cur(); B.chrome.setCompact(false); B.vibe(6);
    if (E.native && cur.url && !cur.priv) await Promise.race([T.capture(cur), new Promise(r => setTimeout(r, 180))]);
    S.mode = cur.priv ? 'private' : 'normal';
    render();
    el.hidden = false; S.isOpen = true;
    U.push('switcher', () => S.close());
    const card = cardEl(cur.id);
    if (!card) { el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200 }); return; }
    card.scrollIntoView({ block: 'center' });
    const to = rectOf(card.querySelector('.cthumb')), g = ghost(cur, contentRect(), 0);
    card.querySelector('.cthumb').style.visibility = 'hidden';
    el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 240, easing: 'ease-out' });
    await fly(g, contentRect(), to, 0, 20, 360);
    card.querySelector('.cthumb').style.visibility = ''; g.remove();
  };

  S.close = async function (id, instant) {
    if (!S.isOpen || S.closing) return;
    S.closing = true;
    let t = id ? T.byId(id) : null;
    if (!t) {
      t = T.cur();
      if (!t || !!t.priv !== (S.mode === 'private')) t = T.inMode(S.mode === 'private').sort((a, b) => b.lastActive - a.lastActive)[0] || t;
    }
    T.select(t.id);
    const card = cardEl(t.id);
    if (card && !instant) {
      const th = card.querySelector('.cthumb'), from = rectOf(th), g = ghost(t, from, 20);
      th.style.visibility = 'hidden';
      el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, delay: 50, easing: 'ease-in', fill: 'forwards' });
      await fly(g, from, contentRect(), 20, 0, 340);
      g.remove();
    } else await el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 180, fill: 'forwards' }).finished.catch(() => {});
    el.hidden = true; S.isOpen = false; S.closing = false;
    el.getAnimations().forEach(a => a.cancel());
    U.pop('switcher');
  };

  S.thumb = id => { const c = cardEl(id); if (c && S.isOpen) fillThumb(c.querySelector('.cthumb'), T.byId(id)); };
  S.update = t => {
    if (!S.isOpen) return;
    const c = cardEl(t.id); if (!c) return;
    c.querySelector('.ctitle').textContent = T.title(t);
    const tile = c.querySelector('.chead .tile'); if (tile) tile.replaceWith(headTile(t));
    if (!T.thumbs[t.id]) fillThumb(c.querySelector('.cthumb'), t);
  };
})();

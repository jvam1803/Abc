(function () {
  'use strict';
  const B = window.B, { $ } = B, E = B.engine, T = B.tabs, U = B.ui;
  const M = B.main = {};

  // Botão voltar do Android: fecha a camada de cima, depois volta na página, depois fecha a aba.
  // Retorna true se tratou o toque.
  M.onBack = function (web) {
    if (U.closeTop()) return true;
    if (!$('#findbar').hidden) { B.menus.findClose(); return true; }
    const t = T.cur();
    if (t && t.reader) { E.reader(t.id, false); return true; }
    if (T.back()) return true;
    if (t && t.parent && T.byId(t.parent)) { T.close(t.id); return true; }
    if (!web) E.minimize();
    return false;
  };

  function boot() {
    B.chrome.init();
    B.chrome.applyTheme();
    T.restore();
    E.settings(B.data.settings);
    E.ready();
    const mq = matchMedia('(prefers-color-scheme: dark)');
    if (mq.addEventListener) mq.addEventListener('change', () => B.chrome.applyTheme());
    addEventListener('resize', B.layout.sync);

    if (!E.native) {
      // Versão web: captura o "voltar" do navegador para fechar camadas.
      try {
        history.pushState({ bs: 1 }, '');
        addEventListener('popstate', () => { if (M.onBack(true)) history.pushState({ bs: 1 }, ''); });
      } catch (e) { /* sem histórico */ }
      try { if (!window.BUSSOLA_DEMO && 'serviceWorker' in navigator && /^https?:/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {}); } catch (e) { /* sem service worker */ }
    }
    addEventListener('keydown', e => { if (e.key === 'Escape') M.onBack(true); });
    document.documentElement.classList.add('ready');
  }
  boot();
})();

(function () {
  'use strict';
  // Folha de Favoritos / Lista de Leitura / Histórico / Downloads e Relatório de Privacidade.
  const B = window.B, { h } = B, E = B.engine, T = B.tabs, U = B.ui;
  const L = B.lists = {};
  const TABS = [
    { id: 'bookmarks', icon: 'book', title: 'Favoritos' },
    { id: 'reading', icon: 'glasses', title: 'Lista de Leitura' },
    { id: 'history', icon: 'clock', title: 'Histórico' },
    { id: 'downloads', icon: 'down', title: 'Downloads' }
  ];
  let sh = null, tab = 'bookmarks', q = '', rlOnly = false, listEl, bar, search;

  L.open = function (which) {
    tab = which || tab; q = '';
    sh = U.sheet({ title: '', tall: true, left: { icon: 'gear', run: () => { sh.close(); setTimeout(() => B.settings.open(), 300); } }, onClose: () => { sh = null; } });
    search = h('input', { type: 'search', class: 'lsearch', placeholder: 'Buscar', autocomplete: 'off', spellcheck: 'false' });
    search.addEventListener('input', B.debounce(() => { q = search.value.trim().toLowerCase(); renderList(); }, 120));
    listEl = h('div', { class: 'llist' });
    sh.body.append(h('div', { class: 'lsearch-w' }, B.icon('search', 'sm'), search), listEl);
    bar = h('div', { class: 'lbar' }, TABS.map(t => h('button', { class: 'lb', 'data-t': t.id, 'aria-label': t.title, onclick: () => { tab = t.id; q = ''; search.value = ''; renderList(); sh.body.scrollTop = 0; } }, B.icon(t.icon))));
    sh.panel.append(bar);
    renderList();
  };
  L.refreshIfOpen = name => { if (sh && tab === name) renderList(); };

  const visible = arr => arr.filter(x => !q || (x.title || '').toLowerCase().includes(q) || (x.url || x.name || '').toLowerCase().includes(q));
  const go = url => { sh.close(); const t = T.cur(); setTimeout(() => T.navigate(t, url), 120); };
  const openNew = (url, priv) => { sh.close(); setTimeout(() => T.create({ url, priv: !!priv, parent: priv ? null : T.active }), 120); };
  const note = txt => h('div', { class: 'lempty' }, h('span', { text: txt }));

  function rowEl(x, o) {
    const btn = h('button', { class: 'lrow press', onclick: () => o.open(x) }, B.tile(x.url, x.title, 34),
      h('div', { class: 'ltxt' }, h('b', { text: x.title || B.host(x.url) }), h('span', { text: o.sub || B.host(x.url) })),
      o.right ? h('span', { class: 'lright', text: o.right }) : null, o.dot ? h('i', { class: 'ldot' }) : null);
    B.longPress(btn, () => U.menu(btn, [
      { label: 'Abrir em Nova Aba', icon: 'plus', run: () => openNew(x.url) },
      { label: 'Abrir em Aba Privada', icon: 'incog', run: () => openNew(x.url, true) },
      { label: 'Copiar Link', icon: 'copy', run: () => { E.copy(x.url); U.toast('Link copiado'); } },
      o.extra ? o.extra(x) : null,
      { label: 'Excluir', icon: 'trash', danger: true, run: () => { o.del(x); renderList(); } }
    ], { width: 250 }));
    return U.swipe(btn, () => o.del(x));
  }
  const grp = rows => h('div', { class: 'lgrp' }, rows);
  const head = t => h('div', { class: 'lhead', text: t });

  function renderList() {
    if (!sh) return;
    listEl.innerHTML = '';
    const info = TABS.find(t => t.id === tab);
    sh.title.textContent = info.title;
    bar.querySelectorAll('.lb').forEach(b => b.classList.toggle('on', b.dataset.t === tab));
    search.parentNode.hidden = tab === 'downloads';
    if (tab === 'bookmarks') {
      const fav = visible(B.data.favorites), bm = visible(B.data.bookmarks);
      if (fav.length) listEl.append(head('Página Inicial'), grp(fav.map(x => rowEl(x, { open: x => go(x.url), del: x => { B.fav.remove(x.url); B.start.invalidate(); } }))));
      if (bm.length) listEl.append(head('Favoritos'), grp(bm.map(x => rowEl(x, { open: x => go(x.url), del: x => B.bm.remove(x.url) }))));
      if (!fav.length && !bm.length) listEl.append(note(q ? 'Nada encontrado.' : 'Nenhum favorito. Use Compartilhar › Adicionar Favorito.'));
    } else if (tab === 'reading') {
      const seg = h('div', { class: 'rseg' }, ['Tudo', 'Não lidas'].map((l, i) => h('button', { class: (!!i === rlOnly ? 'on' : ''), text: l, onclick: () => { rlOnly = !!i; renderList(); } })));
      listEl.append(seg);
      const items = visible(B.data.reading).filter(r => !rlOnly || !r.read);
      if (items.length) listEl.append(grp(items.map(x => rowEl(x, {
        open: x => { B.rl.mark(x.url, true); go(x.url); }, del: x => B.rl.remove(x.url), dot: !x.read,
        extra: x => ({ label: x.read ? 'Marcar como não lido' : 'Marcar como lido', icon: 'check', run: () => { B.rl.mark(x.url, !x.read); renderList(); } })
      }))));
      else listEl.append(note(q ? 'Nada encontrado.' : 'A Lista de Leitura guarda páginas para ler depois.'));
    } else if (tab === 'history') {
      const all = visible(B.data.history), items = all.slice(0, 250);
      listEl.append(h('button', { class: 'lclear', text: 'Limpar Histórico…', onclick: clearHistory }));
      if (!items.length) listEl.append(note(q ? 'Nada encontrado.' : 'Nenhuma página visitada.'));
      let day = '', box = null;
      items.forEach(x => {
        const d = B.dayLabel(x.ts);
        if (d !== day) { day = d; listEl.append(head(d)); box = grp([]); listEl.append(box); }
        box.append(rowEl(x, { right: B.hhmm(x.ts), open: x => go(x.url), del: x => B.hist.removeAt(x.ts, x.url) }));
      });
      if (all.length > items.length) listEl.append(note('Mostrando os 250 mais recentes. Use a busca para achar outros.'));
    } else {
      const d = B.data.downloads;
      if (d.length) listEl.append(h('button', { class: 'lclear', text: 'Limpar lista', onclick: () => { B.data.downloads = []; B.save('downloads'); renderList(); } }),
        grp(d.map(x => h('div', { class: 'lrow dl' }, h('div', { class: 'dlic' }, B.icon('down', 'sm')),
          h('div', { class: 'ltxt' }, h('b', { text: x.name }), h('span', { text: B.host(x.url) + ' • ' + B.dayLabel(x.ts) + ' ' + B.hhmm(x.ts) }))))),
          note('Os arquivos ficam na pasta Downloads do aparelho.'));
      else listEl.append(note('Nenhum download ainda.'));
    }
  }

  function clearHistory() {
    const now = new Date(), day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const doIt = since => () => { B.hist.clear(since); B.start.invalidate(); renderList(); U.toast('Histórico limpo'); };
    U.actions('Limpar histórico', [
      { label: 'Última hora', run: doIt(Date.now() - 36e5) },
      { label: 'Hoje', run: doIt(day0) },
      { label: 'Hoje e ontem', run: doIt(day0 - 864e5) },
      { label: 'Todo o histórico', danger: true, run: doIt(0) }
    ]);
  }

  L.privacy = function () {
    const p = B.data.privacy, top = B.priv.top(8);
    const s = U.sheet({ title: 'Relatório de Privacidade', tall: true });
    const days = Math.max(1, Math.round((Date.now() - p.since) / 864e5));
    s.body.append(h('div', { class: 'pv-hero' }, h('div', { class: 'shield big' }, B.icon('shield')),
      h('b', { text: String(p.total) }), h('span', { text: 'rastreadores impedidos' + (days > 1 ? ' em ' + days + ' dias' : '') })),
      top.length ? h('div', { class: 'lhead', text: 'Mais frequentes' }) : null,
      top.length ? grp(top.map(([host, n]) => h('div', { class: 'lrow' }, h('div', { class: 'ltxt' }, h('b', { text: host })), h('span', { class: 'lright', text: String(n) })))) : note('Nenhum rastreador bloqueado ainda.'),
      h('button', { class: 'lclear', text: 'Zerar contagem', onclick: () => { B.data.privacy = { total: 0, since: Date.now(), hosts: {} }; B.save('privacy'); s.close(); B.start.invalidate(); } }));
  };
})();

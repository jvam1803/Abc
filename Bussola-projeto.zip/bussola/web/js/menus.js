(function () {
  'use strict';
  // Menu "Aa", folha Compartilhar, busca na página e menus de toque longo.
  const B = window.B, { $, h } = B, E = B.engine, T = B.tabs, U = B.ui;
  const M = B.menus = {};
  const ZOOMS = [50, 75, 85, 100, 115, 125, 150, 175, 200, 250, 300];
  let findTab = null, findCount = null, findInput = null;

  M.onTabChange = t => { if (findTab && findTab !== t.id) M.findClose(); };

  function readerOpts() {
    const r = B.data.settings.reader = B.data.settings.reader || { size: 100, theme: 'white', font: 'sans' };
    if (r.theme === 'sepia') r.theme = 'silver';
    return r;
  }
  function readerNode(t) {
    const r = readerOpts(), push = () => { B.save('settings'); E.readerOpts(t.id, r); };
    const themes = [['white', '#ffffff'], ['silver', '#d6d6d6'], ['gray', '#5a5a5a'], ['black', '#000000']];
    return h('div', { class: 'rd' },
      h('div', { class: 'zrow' },
        h('button', { class: 'zb small', onclick: () => { r.size = Math.max(70, r.size - 10); push(); } }, 'A'),
        h('button', { class: 'zb font', text: r.font === 'serif' ? 'Serifa' : 'Sem serifa', onclick: e => { r.font = r.font === 'serif' ? 'sans' : 'serif'; e.currentTarget.textContent = r.font === 'serif' ? 'Serifa' : 'Sem serifa'; push(); } }),
        h('button', { class: 'zb big', onclick: () => { r.size = Math.min(220, r.size + 10); push(); } }, 'A')),
      h('div', { class: 'rthemes' }, themes.map(([n, c]) => h('button', { class: 'rt' + (r.theme === n ? ' on' : ''), style: 'background:' + c, 'aria-label': n,
        onclick: e => { r.theme = n; push(); e.currentTarget.parentNode.querySelectorAll('.rt').forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }))));
  }

  M.aa = function () {
    const t = T.cur(); if (!t || !t.url) return;
    const pct = h('span', { class: 'zpct', text: t.zoom + '%' });
    const setZ = d => {
      let i = ZOOMS.indexOf(t.zoom); if (i < 0) i = 3;
      t.zoom = ZOOMS[Math.max(0, Math.min(ZOOMS.length - 1, i + d))];
      pct.textContent = t.zoom + '%'; E.setZoom(t.id, t.zoom); T.persist();
    };
    const zrow = h('div', { class: 'zrow' }, h('button', { class: 'zb small', onclick: () => setZ(-1) }, 'A'), pct, h('button', { class: 'zb big', onclick: () => setZ(1) }, 'A'));
    const canReader = E.canReader && (t.readable || t.reader);
    U.menu($('#btn-aa'), [
      { node: t.reader ? readerNode(t) : zrow },
      { sep: true },
      canReader ? { label: t.reader ? 'Ocultar Leitor' : 'Mostrar Leitor', icon: 'reader', run: () => E.reader(t.id, !t.reader) } : null,
      { label: 'Solicitar Site para Computador', icon: 'desktop', checked: t.desktop, run: () => { t.desktop = !t.desktop; E.setDesktop(t.id, t.desktop); T.changed(t); U.toast(t.desktop ? 'Versão para computador' : 'Versão para celular'); } },
      { label: 'Ocultar Barra de Ferramentas', icon: 'down', run: () => B.chrome.setCompact(true) },
      { label: 'Buscar na Página', icon: 'search', run: M.find },
      { sep: true },
      { label: 'Abrir no Navegador do Sistema', icon: 'ext', run: () => E.external(t.url) }
    ], { width: 312 });
  };

  M.share = function () {
    const t = T.cur(); if (!t) return;
    if (!t.url) { U.toast('Abra uma página para compartilhar'); return; }
    const url = t.url, title = T.title(t);
    const s = U.sheet({ title: '' });
    const act = (icon, label, run, extra) => h('button', { class: 'arow press', onclick: () => { s.close(); setTimeout(run, 120); } }, h('span', { text: label }), B.icon(icon, 'sm'), extra || null);
    s.body.append(
      h('div', { class: 'shead' }, B.tile(url, title, 46), h('div', { class: 'ltxt' }, h('b', { text: title }), h('span', { text: B.host(url) }))),
      h('div', { class: 'sbtns' },
        h('button', { class: 'sbtn press', onclick: () => { s.close(); E.share(url, title); } }, B.icon('share'), h('span', { text: 'Enviar…' })),
        h('button', { class: 'sbtn press', onclick: () => { E.copy(url); s.close(); U.toast('Link copiado'); } }, B.icon('copy'), h('span', { text: 'Copiar Link' })),
        h('button', { class: 'sbtn press', onclick: () => { s.close(); setTimeout(() => T.create({ url, parent: t.id }), 120); } }, B.icon('plus'), h('span', { text: 'Duplicar Aba' }))),
      h('div', { class: 'lgrp' },
        act('glasses', B.rl.has(url) ? 'Já está na Lista de Leitura' : 'Adicionar à Lista de Leitura', () => { if (B.rl.add(url, title)) U.toast('Adicionado à Lista de Leitura'); }),
        act('book', B.bm.has(url) ? 'Remover dos Favoritos' : 'Adicionar Favorito', () => { if (B.bm.has(url)) { B.bm.remove(url); U.toast('Favorito removido'); } else { B.bm.add(url, title); U.toast('Favorito adicionado'); } }),
        act('star', B.fav.has(url) ? 'Remover da Página Inicial' : 'Adicionar à Página Inicial', () => { if (B.fav.has(url)) B.fav.remove(url); else B.fav.add(url, title); B.start.invalidate(); U.toast(B.fav.has(url) ? 'Adicionado à Página Inicial' : 'Removido da Página Inicial'); })),
      h('div', { class: 'lgrp' },
        act('search', 'Buscar na Página', M.find),
        act('desktop', t.desktop ? 'Solicitar Site para Celular' : 'Solicitar Site para Computador', () => { t.desktop = !t.desktop; E.setDesktop(t.id, t.desktop); T.changed(t); }),
        act('reader', 'Imprimir ou Salvar PDF', () => E.print(t.id)),
        act('ext', 'Abrir no Navegador do Sistema', () => E.external(url))));
  };

  // Busca na página (barra acima da pílula).
  M.find = function () {
    const t = T.cur(); if (!t || !t.url) return;
    if (!E.canFind) { U.toast('A busca na página funciona só no app Android'); return; }
    const fb = $('#findbar'); if (!fb.hidden) { findInput.focus(); return; }
    B.chrome.setCompact(false);
    fb.innerHTML = ''; fb.hidden = false; findTab = t.id;
    findInput = h('input', { type: 'search', placeholder: 'Buscar na página', enterkeyhint: 'search', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false' });
    findCount = h('span', { class: 'fcount' });
    fb.append(h('div', { class: 'ffield' }, B.icon('search', 'sm'), findInput, findCount),
      h('button', { class: 'fnav', 'aria-label': 'Anterior', onclick: () => E.findNext(findTab, false) }, B.icon('up')),
      h('button', { class: 'fnav', 'aria-label': 'Próximo', onclick: () => E.findNext(findTab, true) }, B.icon('down')),
      h('button', { class: 'fdone', text: 'OK', onclick: M.findClose }));
    findInput.addEventListener('input', B.debounce(() => { if (findInput.value) E.find(findTab, findInput.value); else { E.findClear(findTab); findCount.textContent = ''; } }, 150));
    findInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); E.findNext(findTab, !e.shiftKey); } });
    B.layout.sync(); setTimeout(() => findInput.focus(), 60);
  };
  M.findClose = function () {
    const fb = $('#findbar'); if (fb.hidden) return;
    fb.hidden = true; fb.innerHTML = '';
    if (findTab) E.findClear(findTab);
    findTab = null; B.layout.sync();
  };
  M.onFind = (active, total) => { if (findCount) findCount.textContent = total ? (active + 1) + ' de ' + total : (findInput && findInput.value ? 'Nada' : ''); };

  // Toque longo em link ou imagem dentro da página (vem do app).
  M.linkMenu = function (ev) {
    const t = T.byId(ev.id), url = ev.url, img = ev.img;
    const list = [];
    if (url) {
      list.push({ label: 'Abrir', run: () => t && T.navigate(t, url) });
      list.push({ label: 'Abrir em Nova Aba', run: () => T.create({ url, parent: ev.id, bg: !!B.data.settings.bgTabs }) });
      list.push({ label: 'Abrir em Aba Privada', run: () => T.create({ url, priv: true }) });
      list.push({ label: 'Copiar Link', run: () => { E.copy(url); U.toast('Link copiado'); } });
      list.push({ label: 'Compartilhar…', run: () => E.share(url, '') });
    }
    if (img) {
      if (!url) list.push({ label: 'Abrir Imagem em Nova Aba', run: () => T.create({ url: img, parent: ev.id }) });
      list.push({ label: 'Copiar Endereço da Imagem', run: () => { E.copy(img); U.toast('Endereço copiado'); } });
      list.push({ label: 'Baixar Imagem', run: () => E.download(img) });
    }
    if (list.length) U.actions(url ? B.host(url) || url : B.host(img) || img, list);
  };

  M.tabsMenu = function (anchor) {
    const t = T.cur();
    U.menu(anchor, [
      { label: 'Nova Aba', icon: 'plus', run: () => T.create() },
      { label: 'Nova Aba Privada', icon: 'incog', run: () => T.create({ priv: true }) },
      { sep: true },
      { label: 'Fechar Esta Aba', icon: 'x', run: () => T.close(t.id) },
      T.inMode(t.priv).length > 1 ? { label: 'Fechar Outras Abas', icon: 'trash', danger: true, run: () => T.closeOthers(t.id) } : null,
      { sep: true },
      { label: 'Ajustes', icon: 'gear', run: () => B.settings.open() }
    ]);
  };

  // Toque longo em "voltar": páginas visitadas há pouco.
  M.backMenu = function (anchor) {
    const seen = {}, items = [];
    for (const x of B.data.history) { if (seen[x.url]) continue; seen[x.url] = 1; items.push(x); if (items.length >= 6) break; }
    if (!items.length) return;
    U.menu(anchor, items.map(x => ({ label: (x.title || B.host(x.url)).slice(0, 38), icon: 'clock', run: () => T.navigate(T.cur(), x.url) })), { width: 300 });
  };
})();

(function () {
  'use strict';
  const B = window.B;
  const mem = {};
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return mem[k] == null ? null : mem[k]; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } }
  };
  const NATIVE = !!window.BussolaNative;
  const here = p => { try { return new URL(p, location.href).href; } catch (e) { return p; } };

  const DEF = {
    settings: {
      engine: NATIVE ? 'google' : 'wikipedia', suggest: true, theme: 'auto', block: true, desktop: false,
      bgTabs: false, autoClose: 'manual', secFav: true, secPriv: true, secRead: true, secFreq: true, saveHistory: true
    },
    favorites: window.BUSSOLA_DEMO ? [
      { url: here('demo/artigo.html'), title: 'Como funciona uma bússola' },
      { url: here('demo/galeria.html'), title: 'Galeria em cinza' },
      { url: 'https://pt.wikipedia.org/', title: 'Wikipédia' },
      { url: 'https://www.google.com/', title: 'Google' },
      { url: 'https://www.youtube.com/', title: 'YouTube' },
      { url: 'https://g1.globo.com/', title: 'G1' }
    ] : [
      { url: 'https://pt.wikipedia.org/', title: 'Wikipédia' },
      { url: 'https://www.google.com/', title: 'Google' },
      { url: 'https://www.youtube.com/', title: 'YouTube' },
      { url: 'https://duckduckgo.com/', title: 'DuckDuckGo' },
      { url: 'https://g1.globo.com/', title: 'G1' },
      { url: 'https://www.mercadolivre.com.br/', title: 'Mercado Livre' }
    ],
    bookmarks: [], history: [], reading: [], downloads: [],
    privacy: { total: 0, since: Date.now(), hosts: {} },
    tabs: { list: [], active: null },
    icons: {}
  };

  B.data = {};
  Object.keys(DEF).forEach(k => {
    let v = null;
    try { const raw = ls.get('bs.' + k); v = raw ? JSON.parse(raw) : null; } catch (e) { v = null; }
    if (v == null) v = JSON.parse(JSON.stringify(DEF[k]));
    else if (k === 'settings') v = Object.assign({}, DEF.settings, v);
    B.data[k] = v;
  });

  const timers = {};
  B.save = k => { clearTimeout(timers[k]); timers[k] = setTimeout(() => ls.set('bs.' + k, JSON.stringify(B.data[k])), 300); };
  B.saveNow = () => Object.keys(B.data).forEach(k => ls.set('bs.' + k, JSON.stringify(B.data[k])));
  B.lsGet = ls.get; B.lsSet = ls.set;
  addEventListener('pagehide', B.saveNow);
  document.addEventListener('visibilitychange', () => { if (document.hidden) B.saveNow(); });

  // Listas simples de URLs (favoritos, lista de leitura, favoritos da página inicial)
  function urlList(key) {
    return {
      has: u => B.data[key].some(x => x.url === u),
      add(url, title) {
        if (this.has(url)) return false;
        B.data[key].unshift({ url, title: title || B.host(url) || url, ts: Date.now() });
        B.save(key); return true;
      },
      remove(url) { B.data[key] = B.data[key].filter(x => x.url !== url); B.save(key); }
    };
  }
  B.bm = urlList('bookmarks');
  B.rl = urlList('reading');
  B.fav = urlList('favorites');
  B.fav.add = function (url, title) {   // favoritos da página inicial entram no fim
    if (this.has(url)) return false;
    B.data.favorites.push({ url, title: title || B.host(url) || url, ts: Date.now() });
    B.save('favorites'); return true;
  };
  B.rl.mark = function (url, read) { const x = B.data.reading.find(r => r.url === url); if (x) { x.read = read; B.save('reading'); } };

  B.hist = {
    add(url, title) {
      if (!B.data.settings.saveHistory || !/^https?:/i.test(url)) return;
      const H = B.data.history, l = H[0];
      if (l && l.url === url) { l.ts = Date.now(); if (title) l.title = title; }
      else H.unshift({ url, title: title || B.host(url), ts: Date.now() });
      if (H.length > 3000) H.length = 3000;
      B.save('history');
    },
    setTitle(url, title) {
      if (!title) return;
      const x = B.data.history.slice(0, 6).find(h => h.url === url);
      if (x && x.title !== title) { x.title = title; B.save('history'); }
    },
    removeAt(ts, url) { B.data.history = B.data.history.filter(h => !(h.ts === ts && h.url === url)); B.save('history'); },
    clear(sinceTs) { B.data.history = sinceTs ? B.data.history.filter(h => h.ts < sinceTs) : []; B.save('history'); },
    frequent(n) {
      const c = {};
      B.data.history.slice(0, 500).forEach(h => {
        const k = B.host(h.url); if (!k) return;
        const e = c[k] || (c[k] = { n: 0, url: h.url, title: h.title, host: k });
        e.n++;
      });
      return Object.values(c).sort((a, b) => b.n - a.n).slice(0, n);
    }
  };

  B.icons = {
    get: host => B.data.icons[host] || null,
    set(host, data) {
      if (!host || !data) return;
      B.data.icons[host] = data;
      const keys = Object.keys(B.data.icons);
      if (keys.length > 160) delete B.data.icons[keys[0]];
      B.save('icons');
    }
  };

  B.priv = {
    hit(host, n) {
      n = n || 1;
      const p = B.data.privacy; p.total += n; p.hosts[host] = (p.hosts[host] || 0) + n;
      const ks = Object.keys(p.hosts); if (ks.length > 80) delete p.hosts[ks[0]];
      B.save('privacy');
    },
    top(n) { return Object.entries(B.data.privacy.hosts).sort((a, b) => b[1] - a[1]).slice(0, n); }
  };

  B.dl = {
    add(name, url) { B.data.downloads.unshift({ name, url, ts: Date.now() }); if (B.data.downloads.length > 100) B.data.downloads.length = 100; B.save('downloads'); }
  };
})();

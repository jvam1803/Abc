(function () {
  'use strict';
  // Tela de Ajustes.
  const B = window.B, { h } = B, E = B.engine, U = B.ui;
  const S = B.settings = {};
  B.version = '1.1.0';

  const ENGINES = Object.keys(B.ENGINES).map(k => [k, B.ENGINES[k].name]);
  const THEMES = [['auto', 'Automático'], ['light', 'Claro'], ['dark', 'Escuro']];
  const CLOSE = [['manual', 'Manualmente'], ['day', 'Após um dia'], ['week', 'Após uma semana'], ['month', 'Após um mês']];

  function set(k, v) {
    B.data.settings[k] = v; B.save('settings');
    if (k === 'theme') B.chrome.applyTheme();
    else if (k === 'block') E.settings(B.data.settings);
    else if (/^sec/.test(k)) B.start.invalidate();
  }

  const row = (label, right, onclick, sub) => h(onclick ? 'button' : 'div', { class: 'srow' + (onclick ? ' press' : ''), onclick },
    h('div', { class: 'stxt' }, h('b', { text: label }), sub ? h('span', { text: sub }) : null), right);

  function toggle(label, key, sub, disabled) {
    const sw = h('span', { class: 'switch' + (B.data.settings[key] ? ' on' : '') + (disabled ? ' dis' : '') }, h('i'));
    return row(label, sw, disabled ? null : () => { const v = !B.data.settings[key]; set(key, v); sw.classList.toggle('on', v); }, sub);
  }
  function choose(label, key, opts) {
    const val = h('span', { class: 'sval' });
    const cur = () => (opts.find(o => o[0] === B.data.settings[key]) || opts[0])[1];
    val.textContent = cur();
    return row(label, h('span', { class: 'sright' }, val, B.icon('fwd', 'sm')), () => U.actions(label,
      opts.map(o => ({ label: o[1], checked: o[0] === B.data.settings[key], run: () => { set(key, o[0]); val.textContent = cur(); } }))));
  }
  const group = (title, rows, foot) => h('div', { class: 'sgrp' }, title ? h('div', { class: 'lhead', text: title }) : null,
    h('div', { class: 'lgrp' }, rows), foot ? h('div', { class: 'sfoot', text: foot }) : null);

  function clearData() {
    U.actions('Limpar histórico e dados', [
      { label: 'Histórico de navegação', run: () => { B.hist.clear(0); B.start.invalidate(); U.toast('Histórico limpo'); } },
      E.canClear ? { label: 'Cookies e dados de sites', run: () => { E.clear('cookies'); U.toast('Cookies removidos'); } } : null,
      E.canClear ? { label: 'Cache', run: () => { E.clear('cache'); U.toast('Cache limpo'); } } : null,
      { label: 'Tudo', danger: true, run: () => { B.hist.clear(0); B.data.icons = {}; B.save('icons'); E.clear('all'); B.start.invalidate(); U.toast('Dados removidos'); } }
    ].filter(Boolean));
  }

  S.open = function () {
    const sh = U.sheet({ title: 'Ajustes', tall: true });
    sh.body.classList.add('settings');
    sh.body.append(
      group('Pesquisa', [choose('Mecanismo de busca', 'engine', ENGINES), toggle('Sugestões de pesquisa', 'suggest')]),
      group('Geral', [
        choose('Aparência', 'theme', THEMES), choose('Fechar abas', 'autoClose', CLOSE),
        toggle('Site para computador por padrão', 'desktop')]),
      group('Privacidade e segurança', [
        toggle('Bloquear rastreadores', 'block', E.canBlock ? 'Impede anúncios e rastreadores conhecidos' : 'Disponível no app Android', !E.canBlock),
        toggle('Salvar histórico', 'saveHistory'),
        row('Limpar histórico e dados', B.icon('fwd', 'sm'), clearData)]),
      group('Página inicial', [
        toggle('Favoritos', 'secFav'), toggle('Relatório de Privacidade', 'secPriv'),
        toggle('Lista de Leitura', 'secRead'), toggle('Visitados com frequência', 'secFreq')]),
      group(null, [row('Downloads', B.icon('fwd', 'sm'), () => { sh.close(); setTimeout(() => B.lists.open('downloads'), 300); })]),
      group('Sobre', [row('Bússola', h('span', { class: 'sval', text: 'versão ' + B.version }))],
        'Navegador criado sob medida. Não tem relação com a Apple nem com o Safari.'));
  };
})();

(function () {
  'use strict';
  // Tela de endereço/pesquisa: digitar, sugestões, favoritos e histórico.
  const B = window.B, { $, h } = B, E = B.engine, T = B.tabs, U = B.ui;
  const O = B.omni = {};
  let root, input, list, clearBtn, seq = 0, pristine = true, built = false;

  function build() {
    root = $('#omni');
    input = h('input', { type: 'text', inputmode: 'url', enterkeyhint: 'go', autocapitalize: 'off', autocomplete: 'off', autocorrect: 'off', spellcheck: 'false', placeholder: 'Pesquisar ou inserir site' });
    clearBtn = h('button', { class: 'oclear', 'aria-label': 'Limpar', onclick: () => { input.value = ''; input.focus(); pristine = false; update(); } }, B.icon('x', 'sm'));
    list = h('div', { class: 'omni-list scroll' });
    root.append(list, h('div', { class: 'omni-bar' },
      h('div', { class: 'omni-field glass gleam' }, B.icon('search', 'sm'), input, clearBtn),
      h('button', { class: 'omni-cancel glass gleam', text: 'Cancelar', onclick: O.close })));
    input.addEventListener('input', () => { pristine = false; update(); });
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); O.submit(input.value); } });
    list.addEventListener('scroll', () => input.blur(), { passive: true });
    built = true;
  }

  const update = () => { clearBtn.hidden = !input.value; render(pristine ? '' : input.value); };

  O.open = function (text) {
    if (!built) build();
    const t = T.cur();
    root.hidden = false; root.classList.remove('out'); void root.offsetWidth; root.classList.add('in');
    input.value = text != null ? text : (t && t.url) || '';
    pristine = text == null; update();
    U.push('omni', O.close);
    setTimeout(() => { input.focus(); input.select(); }, 30);
  };
  O.close = function () {
    if (root.hidden) return;
    input.blur(); root.classList.remove('in'); root.classList.add('out');
    setTimeout(() => { if (!root.classList.contains('in')) root.hidden = true; }, 200);
    U.pop('omni');
  };
  O.go = function (url) {
    O.close();
    const t = T.cur(); if (!t) return;
    B.chrome.setCompact(false);
    T.navigate(t, url);
  };
  O.submit = function (raw) { const p = B.parseInput(raw); if (p) O.go(p.url); };

  function row(lead, main, sub, run, fill) {
    return h('button', { class: 'orow', onclick: run }, lead,
      h('div', { class: 'otxt' }, h('b', { text: main }), sub ? h('span', { text: sub }) : null),
      fill ? h('span', { class: 'ofill', role: 'button', onclick: e => { e.stopPropagation(); input.value = fill; pristine = false; input.focus(); update(); } }, B.icon('fill', 'sm')) : null);
  }
  const lead = n => h('div', { class: 'olead' }, B.icon(n, 'sm'));
  const sect = (title, rows) => rows.length ? h('div', { class: 'osec' }, title ? h('div', { class: 'osh', text: title }) : null, h('div', { class: 'ogrp' }, rows)) : null;

  function render(q) {
    const my = ++seq; list.innerHTML = '';
    q = q.trim();
    if (!q) return empty();
    const p = B.parseInput(q), eng = B.ENGINES[B.data.settings.engine] || B.ENGINES.google;
    const top = [];
    if (p && !p.search) top.push(row(lead('globe'), q, 'Abrir ' + B.host(p.url), () => O.go(p.url)));
    top.push(row(lead('search'), 'Pesquisar “' + q + '”', eng.name, () => O.go(B.searchUrl(q, B.data.settings.engine))));
    list.append(sect(null, top));
    const sugBox = h('div'); list.append(sugBox);

    const ql = q.toLowerCase(), seen = {}, hits = [];
    const add = (x, kind) => {
      if (hits.length >= 6 || seen[x.url]) return;
      if ((x.title || '').toLowerCase().includes(ql) || x.url.toLowerCase().includes(ql)) { seen[x.url] = 1; hits.push({ x, kind }); }
    };
    B.data.favorites.forEach(x => add(x, 'Favorito')); B.data.bookmarks.forEach(x => add(x, 'Favorito'));
    B.data.history.slice(0, 600).forEach(x => add(x, 'Histórico'));
    const hr = hits.map(o => row(B.tile(o.x.url, o.x.title, 30), o.x.title || B.host(o.x.url), B.host(o.x.url) + ' — ' + o.kind, () => O.go(o.x.url)));
    const hs = sect('Favoritos e Histórico', hr); if (hs) list.append(hs);

    E.suggest(q).then(arr => {
      if (my !== seq || !arr.length) return;
      sugBox.replaceWith(sect('Sugestões', arr.filter(s => s.toLowerCase() !== q.toLowerCase()).slice(0, 6)
        .map(s => row(lead('search'), s, null, () => O.go(B.searchUrl(s, B.data.settings.engine)), s))));
    });
  }

  function empty() {
    const favs = B.data.favorites.slice(0, 8);
    if (favs.length) list.append(h('div', { class: 'osec' }, h('div', { class: 'osh', text: 'Favoritos' }),
      h('div', { class: 'ofavs' }, favs.map(f => h('button', { class: 'ofav', onclick: () => O.go(f.url) }, B.tile(f.url, f.title, 58), h('span', { text: f.title }))))));
    const seen = {}, rec = [];
    for (const x of B.data.history) { const k = B.host(x.url); if (!k || seen[k]) continue; seen[k] = 1; rec.push(x); if (rec.length >= 6) break; }
    const s = sect('Visitados recentemente', rec.map(x => row(B.tile(x.url, x.title, 30), x.title || B.host(x.url), B.host(x.url), () => O.go(x.url))));
    if (s) list.append(s);
  }
})();

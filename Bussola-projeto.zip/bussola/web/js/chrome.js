(function () {
  'use strict';
  // Barra inferior (pílula de endereço + barra de ferramentas): estado, gestos e tema.
  const B = window.B, { $ } = B, E = B.engine, T = B.tabs, U = B.ui;
  const C = B.chrome = { compact: false };
  const app = $('#app');
  let lastProg = 0, lastPriv = null, swipedAt = 0;

  C.refresh = function () {
    const t = T.cur(); if (!t) return;
    const has = !!t.url, box = $('#urlbox');
    $('#url-text').textContent = has ? (B.host(t.url) || t.url) : 'Pesquisar ou inserir site';
    box.classList.toggle('empty', !has);
    box.classList.toggle('insecure', has && /^http:/i.test(t.url) && !/^(localhost|127\.|10\.|192\.168\.)/.test(B.host(t.url)));
    $('#btn-reload use').setAttribute('href', t.loading ? '#i-x' : '#i-reload');
    $('#btn-reload').disabled = !has; $('#btn-aa').disabled = !has;
    $('#tb-back').disabled = !t.canBack; $('#tb-fwd').disabled = !t.canFwd;
    $('#tab-count').textContent = T.inMode(t.priv).length;

    const pr = $('#pill-progress');
    if (t.progress < lastProg) { pr.style.transition = 'none'; pr.style.transform = 'scaleX(0)'; pr.offsetWidth; pr.style.transition = ''; }
    lastProg = t.progress;
    pr.style.transform = 'scaleX(' + Math.min(1, t.progress / 100) + ')';
    pr.style.opacity = t.loading ? '1' : '0';

    app.classList.toggle('priv', !!t.priv);
    if (t.priv !== lastPriv) { lastPriv = t.priv; C.applyTheme(); }
    if (!has || t.error) C.setCompact(false);
    if (B.menus) B.menus.onTabChange(t);
    if (B.start) B.start.sync(t);
    B.layout.sync();
  };

  C.setCompact = function (on) {
    on = !!on; if (on === C.compact) return;
    if (on && (U.stack.length || !$('#findbar').hidden)) return;
    C.compact = on; app.classList.toggle('compact', on); B.layout.sync();
  };
  C.onScroll = dir => { if (dir === 'down') C.setCompact(true); else if (dir === 'up') C.setCompact(false); };

  C.applyTheme = function () {
    const pref = B.data.settings.theme;
    const sys = B.sysDark != null ? B.sysDark : (window.BUSSOLA_HOST_THEME ? window.BUSSOLA_HOST_THEME === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches);
    const dark = pref === 'dark' || (pref === 'auto' && sys);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    const t = T.cur(), d = dark || !!(t && t.priv);
    E.theme(d, d ? '#191919' : '#e9e9e9', d ? '#000000' : '#cdcdcd');
  };

  C.init = function () {
    $('#tb-back').onclick = () => { const t = T.cur(); if (t && t.canBack) E.back(t.id); };
    $('#tb-fwd').onclick = () => { const t = T.cur(); if (t && t.canFwd) E.forward(t.id); };
    $('#tb-share').onclick = () => B.menus.share();
    $('#tb-book').onclick = () => B.lists.open('bookmarks');
    $('#tb-tabs').onclick = () => B.switcher.open();
    $('#btn-aa').onclick = () => B.menus.aa();
    $('#btn-reload').onclick = () => {
      const t = T.cur(); if (!t || !t.url) return;
      if (t.loading) E.stop(t.id); else if (t.error) T.navigate(t, t.url); else E.reload(t.id);
    };
    $('#urlbox').onclick = () => {
      if (performance.now() - swipedAt < 400) return;
      if (C.compact) C.setCompact(false); else B.omni.open();
    };
    B.longPress($('#tb-tabs'), () => B.menus.tabsMenu($('#tb-tabs')));
    B.longPress($('#tb-back'), () => B.menus.backMenu($('#tb-back')));

    // Arrastar a pílula para os lados troca de aba (no fim da fila, abre uma nova).
    const pill = $('#pill'); let sx = 0, sy = 0, t0 = 0, dx = 0, on = false;
    pill.addEventListener('pointerdown', e => { if (e.target.closest('.pill-btn')) return; sx = e.clientX; sy = e.clientY; t0 = performance.now(); dx = 0; on = true; });
    pill.addEventListener('pointermove', e => {
      if (!on) return; dx = e.clientX - sx;
      if (Math.abs(dx) > 12 && Math.abs(e.clientY - sy) < 30) { pill.style.transition = 'none'; pill.style.transform = 'translateX(' + dx * 0.55 + 'px)'; }
    });
    const end = ok => e => {
      if (!on) return; on = false; pill.style.transition = ''; pill.style.transform = '';
      if (!ok || Math.abs(dx) < 70 || Math.abs(e.clientY - sy) > 40 || performance.now() - t0 > 700) return;
      const cur = T.cur(), list = T.inMode(cur.priv), i = list.indexOf(cur), nx = list[i + (dx < 0 ? 1 : -1)];
      swipedAt = performance.now(); B.vibe(10);
      pill.classList.remove('in-l', 'in-r'); void pill.offsetWidth; pill.classList.add(dx < 0 ? 'in-l' : 'in-r');
      if (nx) T.select(nx.id); else if (dx < 0) T.create({ priv: cur.priv });
    };
    pill.addEventListener('pointerup', end(true)); pill.addEventListener('pointercancel', end(false));
  };
})();

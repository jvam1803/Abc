package br.bussola.browser;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;

/** Cria e controla as WebViews das páginas (uma por aba) e avisa a interface por eventos. */
final class PageManager {

    /** O que o gerenciador precisa da Activity. */
    interface Host {
        void emit(JSONObject ev);
        void pickFile(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams params);
        void askGeo(String origin, GeolocationPermissions.Callback cb);
        void askMedia(PermissionRequest req);
        void showCustom(View view, WebChromeClient.CustomViewCallback cb);
        void hideCustom();
        void download(String url, String ua, String cd, String mime);
    }

    static final class Tab {
        final String id;
        boolean desktop;
        boolean priv;
        int zoom = 100;
        String url = "";
        WebView web;
        String dir = "";
        String pending = "";
        int acc;

        Tab(String id) {
            this.id = id;
        }
    }

    private final Activity act;
    private final FrameLayout container;
    private final Host host;
    private final Map<String, Tab> tabs = new HashMap<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final String mobileUa;
    private final String desktopUa;
    private final String readerJs;
    private String shown = "";
    /** Folga (px de CSS) no fim das páginas, para a barra flutuante não cobrir o rodapé. */
    private int inset = 122;
    volatile boolean block = true;

    private final Object blockedLock = new Object();
    private final Map<String, Map<String, Integer>> blocked = new HashMap<>();
    private final AtomicBoolean flushScheduled = new AtomicBoolean(false);

    PageManager(Activity act, FrameLayout container, Host host) {
        this.act = act;
        this.container = container;
        this.host = host;
        String ua = WebSettings.getDefaultUserAgent(act);
        mobileUa = ua.replace("; wv", "").replace(" Version/4.0", "");
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(ua);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + ver + " Safari/537.36";
        readerJs = readAsset(act, "native/reader.js");
    }

    private static String readAsset(Context c, String path) {
        try (InputStream in = c.getAssets().open(path); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // ---------------------------------------------------------------- abas

    void create(String id, String url, boolean desktop, int zoom, boolean priv) {
        Tab t = tabs.get(id);
        if (t == null) {
            t = new Tab(id);
            tabs.put(id, t);
        }
        t.desktop = desktop;
        t.zoom = zoom <= 0 ? 100 : zoom;
        t.priv = priv;
        ensure(t);
        if (url != null && !url.isEmpty() && !url.toLowerCase(Locale.ROOT).startsWith("javascript:")) {
            t.url = url;
            t.web.loadUrl(url);
        }
    }

    private WebView ensure(Tab t) {
        if (t.web == null) {
            t.web = build(t);
            container.addView(t.web, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            t.web.setVisibility(t.id.equals(shown) ? View.VISIBLE : View.GONE);
        }
        return t.web;
    }

    void show(String id) {
        shown = id == null ? "" : id;
        for (Tab t : tabs.values()) {
            if (t.id.equals(shown)) {
                ensure(t).setVisibility(View.VISIBLE);
            } else if (t.web != null) {
                t.web.setVisibility(View.GONE);
            }
        }
    }

    void load(String id, String url) {
        Tab t = tabs.get(id);
        if (t == null || url == null || url.isEmpty()) {
            return;
        }
        if (url.toLowerCase(Locale.ROOT).startsWith("javascript:")) {
            return;
        }
        t.url = url;
        ensure(t).loadUrl(url);
    }

    void back(String id) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null && t.web.canGoBack()) {
            t.web.goBack();
        }
    }

    void forward(String id) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null && t.web.canGoForward()) {
            t.web.goForward();
        }
    }

    void reload(String id) {
        Tab t = tabs.get(id);
        if (t == null) {
            return;
        }
        if (t.web == null) {
            if (!t.url.isEmpty()) {
                ensure(t).loadUrl(t.url);
            }
        } else {
            t.web.reload();
        }
    }

    void stop(String id) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null) {
            t.web.stopLoading();
            host.emit(Js.jo("ev", "progress", "id", id, "p", 100));
            host.emit(Js.jo("ev", "finish", "id", id, "url", t.url, "title", t.web.getTitle() == null ? "" : t.web.getTitle()));
        }
    }

    void destroy(String id) {
        Tab t = tabs.remove(id);
        if (t == null || t.web == null) {
            return;
        }
        WebView w = t.web;
        t.web = null;
        container.removeView(w);
        w.stopLoading();
        w.destroy();
    }

    void destroyAll() {
        for (String id : new ArrayList<>(tabs.keySet())) {
            destroy(id);
        }
    }

    void setDesktop(String id, boolean on) {
        Tab t = tabs.get(id);
        if (t == null) {
            return;
        }
        t.desktop = on;
        if (t.web != null) {
            t.web.getSettings().setUserAgentString(on ? desktopUa : mobileUa);
            t.web.reload();
        }
    }

    /** Muda a folga do fim das páginas e aplica nas que já estão abertas. */
    void setInset(int cssPx) {
        if (cssPx <= 0 || cssPx == inset) {
            return;
        }
        inset = cssPx;
        for (Tab t : tabs.values()) {
            if (t.web != null) {
                injectInset(t.web);
            }
        }
    }

    /**
     * Acrescenta um espaço vazio depois do conteúdo da página (html::after). Assim dá para rolar até o fim
     * sem o rodapé ficar escondido atrás da barra. O valor é convertido para a escala atual da página.
     */
    @SuppressWarnings("deprecation")
    private void injectInset(WebView w) {
        String u = w.getUrl();
        if (u == null || !(u.startsWith("http:") || u.startsWith("https:"))) {
            return;
        }
        float scale = w.getScale();
        float density = act.getResources().getDisplayMetrics().density;
        int css = scale > 0.05f ? Math.round(inset * density / scale) : inset;
        w.evaluateJavascript("(function(){var i='__bs_inset',s=document.getElementById(i);"
                + "if(!s){s=document.createElement('style');s.id=i;(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent='html::after{content:\"\";display:block;height:" + css + "px;pointer-events:none}';})()", null);
    }

    void setZoom(String id, int pct) {
        Tab t = tabs.get(id);
        if (t == null) {
            return;
        }
        t.zoom = pct;
        if (t.web != null) {
            t.web.getSettings().setTextZoom(pct);
        }
    }

    // ---------------------------------------------------------------- ferramentas

    void find(String id, String q) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null && q != null && !q.isEmpty()) {
            t.web.findAllAsync(q);
        }
    }

    void findNext(String id, boolean fwd) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null) {
            t.web.findNext(fwd);
        }
    }

    void findClear(String id) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null) {
            t.web.clearMatches();
        }
    }

    void snap(String id) {
        Tab t = tabs.get(id);
        String data = null;
        try {
            if (t != null && t.web != null && t.web.getWidth() > 0 && t.web.getHeight() > 0) {
                int w = t.web.getWidth();
                int h = t.web.getHeight();
                float sc = 300f / w;
                Bitmap bm = Bitmap.createBitmap(Math.max(1, (int) (w * sc)), Math.max(1, (int) (h * sc)), Bitmap.Config.RGB_565);
                Canvas c = new Canvas(bm);
                c.scale(sc, sc);
                t.web.draw(c);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 62, bo);
                bm.recycle();
                data = "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            }
        } catch (Throwable e) {
            data = null;
        }
        host.emit(Js.jo("ev", "snap", "id", id, "data", data));
    }

    void reader(String id, boolean on, JSONObject opts) {
        Tab t = tabs.get(id);
        if (t == null || t.web == null) {
            return;
        }
        if (on) {
            if (readerJs.isEmpty()) {
                return;
            }
            String o = opts == null ? "{}" : opts.toString();
            t.web.evaluateJavascript(readerJs + ";__bsReader.show(" + o + ")", v ->
                    host.emit(Js.jo("ev", "reader", "id", id, "on", "true".equals(v))));
        } else {
            t.web.reload();
            host.emit(Js.jo("ev", "reader", "id", id, "on", false));
        }
    }

    void readerOpts(String id, JSONObject opts) {
        Tab t = tabs.get(id);
        if (t != null && t.web != null && opts != null) {
            t.web.evaluateJavascript("window.__bsReader&&__bsReader.set(" + opts.toString() + ")", null);
        }
    }

    void print(String id) {
        Tab t = tabs.get(id);
        if (t == null || t.web == null) {
            return;
        }
        PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
        String name = t.web.getTitle() == null || t.web.getTitle().isEmpty() ? "Página" : t.web.getTitle();
        PrintDocumentAdapter a = t.web.createPrintDocumentAdapter(name);
        pm.print(name, a, new PrintAttributes.Builder().build());
    }

    void clear(String what) {
        boolean all = "all".equals(what);
        if (all || "cookies".equals(what)) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
        }
        if (all || "cache".equals(what)) {
            for (Tab t : tabs.values()) {
                if (t.web != null) {
                    t.web.clearCache(true);
                }
            }
        }
        if (all) {
            for (Tab t : tabs.values()) {
                if (t.web != null) {
                    t.web.clearFormData();
                }
            }
        }
    }

    // ---------------------------------------------------------------- criação da WebView

    private WebView build(final Tab t) {
        WebView w = new WebView(act);
        w.setBackgroundColor(Color.WHITE);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setGeolocationEnabled(true);
        s.setSaveFormData(!t.priv);
        s.setCacheMode(t.priv ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        s.setTextZoom(t.zoom);
        s.setUserAgentString(t.desktop ? desktopUa : mobileUa);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new Client(t));
        w.setWebChromeClient(new Chrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> host.download(url, ua, cd, mime));
        w.setFindListener((active, total, done) ->
                host.emit(Js.jo("ev", "find", "id", t.id, "active", active, "total", total)));
        w.setOnLongClickListener(v -> onLongClick(t, (WebView) v));
        w.setOnScrollChangeListener((v, sx, sy, ox, oy) -> onScroll(t, sy, sy - oy));
        return w;
    }

    private void onScroll(Tab t, int y, int dy) {
        if (y <= 0) {
            if (!"up".equals(t.dir)) {
                t.dir = "up";
                t.acc = 0;
                host.emit(Js.jo("ev", "scroll", "id", t.id, "dir", "up"));
            }
            return;
        }
        if (dy == 0) {
            return;
        }
        String d = dy > 0 ? "down" : "up";
        if (!d.equals(t.pending)) {
            t.pending = d;
            t.acc = 0;
        }
        t.acc += Math.abs(dy);
        if (t.acc > ("down".equals(d) ? 36 : 24) && !d.equals(t.dir)) {
            t.dir = d;
            host.emit(Js.jo("ev", "scroll", "id", t.id, "dir", d));
        }
    }

    private boolean onLongClick(final Tab t, WebView w) {
        WebView.HitTestResult r = w.getHitTestResult();
        final String extra = r.getExtra();
        if (extra == null) {
            return false;
        }
        int type = r.getType();
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
            host.emit(Js.jo("ev", "ctx", "id", t.id, "url", extra));
            return true;
        }
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            host.emit(Js.jo("ev", "ctx", "id", t.id, "img", extra));
            return true;
        }
        if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            Handler h = new Handler(Looper.getMainLooper()) {
                @Override
                public void handleMessage(Message m) {
                    String u = m.getData().getString("url");
                    String src = m.getData().getString("src");
                    host.emit(Js.jo("ev", "ctx", "id", t.id, "url", u, "img", src == null ? extra : src));
                }
            };
            w.requestFocusNodeHref(h.obtainMessage());
            return true;
        }
        return false;
    }

    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) {
                return false;
            }
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return true;
        }
    }

    // ---------------------------------------------------------------- rastreadores bloqueados

    private void countBlocked(String id, String hostName) {
        synchronized (blockedLock) {
            Map<String, Integer> m = blocked.get(id);
            if (m == null) {
                m = new HashMap<>();
                blocked.put(id, m);
            }
            Integer old = m.get(hostName);
            m.put(hostName, old == null ? 1 : old + 1);
        }
        if (flushScheduled.compareAndSet(false, true)) {
            main.postDelayed(this::flushBlocked, 700);
        }
    }

    private void flushBlocked() {
        flushScheduled.set(false);
        Map<String, Map<String, Integer>> copy;
        synchronized (blockedLock) {
            copy = new HashMap<>(blocked);
            blocked.clear();
        }
        for (Map.Entry<String, Map<String, Integer>> e : copy.entrySet()) {
            for (Map.Entry<String, Integer> h : e.getValue().entrySet()) {
                host.emit(Js.jo("ev", "blocked", "id", e.getKey(), "host", h.getKey(), "n", h.getValue()));
            }
        }
    }

    // ---------------------------------------------------------------- clientes da WebView

    private final class Client extends WebViewClient {
        private final Tab t;

        Client(Tab t) {
            this.t = t;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String sch = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            if (sch.isEmpty() || sch.equals("http") || sch.equals("https") || sch.equals("about")
                    || sch.equals("data") || sch.equals("blob") || sch.equals("file")
                    || sch.equals("javascript") || sch.equals("view-source")) {
                return false;
            }
            if (!r.hasGesture()) {
                return true;
            }
            try {
                if (sch.equals("intent")) {
                    Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                    String fb = i.getStringExtra("browser_fallback_url");
                    i.addCategory(Intent.CATEGORY_BROWSABLE);
                    i.setComponent(null);
                    i.setSelector(null);
                    try {
                        act.startActivity(i);
                    } catch (ActivityNotFoundException e) {
                        if (fb != null && fb.startsWith("http")) {
                            v.loadUrl(fb);
                        }
                    }
                } else {
                    act.startActivity(new Intent(Intent.ACTION_VIEW, u));
                }
            } catch (Exception e) {
                // nenhum app para abrir este endereço
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            t.url = url;
            t.dir = "";
            t.pending = "";
            t.acc = 0;
            host.emit(Js.jo("ev", "start", "id", t.id, "url", url));
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
            t.url = url;
            host.emit(Js.jo("ev", "url", "id", t.id, "url", url, "canBack", v.canGoBack(), "canFwd", v.canGoForward()));
        }

        @Override
        public void onPageCommitVisible(WebView v, String url) {
            injectInset(v);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            injectInset(v);
            String title = v.getTitle() == null ? "" : v.getTitle();
            host.emit(Js.jo("ev", "finish", "id", t.id, "url", url, "title", title));
            if (!readerJs.isEmpty() && url != null && url.startsWith("http")) {
                v.evaluateJavascript(readerJs + ";__bsReader.readable()", val ->
                        host.emit(Js.jo("ev", "readable", "id", t.id, "on", "true".equals(val))));
            }
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) {
                return;
            }
            String desc = String.valueOf(e.getDescription());
            if (desc.contains("ERR_ABORTED") || desc.contains("ERR_BLOCKED_BY_CLIENT")) {
                return;
            }
            int code = e.getErrorCode();
            String kind = "net";
            String msg;
            if (!online()) {
                kind = "offline";
                msg = "Parece que você está sem conexão com a internet.";
            } else if (code == ERROR_HOST_LOOKUP) {
                msg = "Não foi possível encontrar o servidor. Confira o endereço.";
            } else if (code == ERROR_TIMEOUT) {
                msg = "O servidor demorou demais para responder.";
            } else if (code == ERROR_CONNECT || code == ERROR_IO) {
                msg = "Não foi possível conectar ao servidor.";
            } else {
                msg = "Não foi possível abrir a página (" + desc + ").";
            }
            host.emit(Js.jo("ev", "error", "id", t.id, "url", r.getUrl().toString(), "code", kind, "desc", msg));
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler handler, SslError error) {
            handler.cancel();
            host.emit(Js.jo("ev", "error", "id", t.id, "url", error.getUrl(), "code", "ssl",
                    "desc", "O certificado de segurança deste site não é confiável. Por segurança, a conexão foi bloqueada."));
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            if (!block || r.isForMainFrame()) {
                return null;
            }
            String m = Trackers.match(r.getUrl().getHost());
            if (m == null) {
                return null;
            }
            countBlocked(t.id, m);
            return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
            if (t.web == v) {
                container.removeView(v);
                v.destroy();
                t.web = null;
            }
            host.emit(Js.jo("ev", "error", "id", t.id, "url", t.url, "code", "crash",
                    "desc", "A página foi encerrada por falta de memória. Toque em Tentar novamente."));
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {
        private final Tab t;

        Chrome(Tab t) {
            this.t = t;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            host.emit(Js.jo("ev", "progress", "id", t.id, "p", p));
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            host.emit(Js.jo("ev", "title", "id", t.id, "title", title == null ? "" : title));
        }

        @Override
        public void onReceivedIcon(WebView v, Bitmap icon) {
            try {
                Bitmap b = Bitmap.createScaledBitmap(icon, 64, 64, true);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 100, bo);
                host.emit(Js.jo("ev", "icon", "id", t.id,
                        "data", "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)));
            } catch (Throwable e) {
                // ícone inválido: ignora
            }
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            String nid = "p" + Long.toString(System.nanoTime(), 36);
            Tab nt = new Tab(nid);
            nt.priv = t.priv;
            nt.desktop = t.desktop;
            nt.zoom = t.zoom;
            tabs.put(nid, nt);
            WebView nw = ensure(nt);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nw);
            resultMsg.sendToTarget();
            host.emit(Js.jo("ev", "popup", "id", nid, "parent", t.id, "bg", false));
            return true;
        }

        @Override
        public void onCloseWindow(WebView w) {
            host.emit(Js.jo("ev", "close", "id", t.id));
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            host.pickFile(cb, params);
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            host.askGeo(origin, cb);
        }

        @Override
        public void onPermissionRequest(PermissionRequest req) {
            host.askMedia(req);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            host.showCustom(view, cb);
        }

        @Override
        public void onHideCustomView() {
            host.hideCustom();
        }
    }
}

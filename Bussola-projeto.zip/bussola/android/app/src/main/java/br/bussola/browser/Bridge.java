package br.bussola.browser;

import android.webkit.JavascriptInterface;

/**
 * Ponte exposta apenas à interface do navegador (a página local do app) com o nome "BussolaNative".
 * As páginas da internet nunca recebem este objeto.
 */
public final class Bridge {
    private final MainActivity act;

    Bridge(MainActivity act) {
        this.act = act;
    }

    @JavascriptInterface
    public void post(String json) {
        act.fromJs(json);
    }
}

package br.bussola.browser;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Casca do navegador: uma WebView transparente com a interface (HTML) por cima das WebViews das páginas.
 * Os toques são direcionados à interface (barra de baixo, menus) ou à página, conforme o que está aberto.
 */
public class MainActivity extends Activity implements PageManager.Host {
    private static final int REQ_FILE = 11;
    private static final int REQ_GEO = 12;
    private static final int REQ_MEDIA = 13;

    private Root root;
    private FrameLayout pageHost;
    private WebView ui;
    private PageManager pages;

    private boolean uiReady;
    private final List<JSONObject> queue = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    private boolean uiAll = true;
    /** Áreas (em pixels) onde os toques pertencem à interface: {esquerda, topo, direita, base}. */
    private int[][] uiRects = new int[0][];

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin;
    private PermissionRequest mediaReq;
    private String[] mediaRes;
    private int barTop = 0xFFE9E9E9;
    private int barBottom = 0xFFCDCDCD;
    private boolean barDark;

    /** Verdadeiro se o ponto está sobre a barra flutuante (ou outra peça da interface). */
    private boolean inUiRect(float x, float y) {
        for (int[] r : uiRects) {
            if (x >= r[0] && x < r[2] && y >= r[1] && y < r[3]) {
                return true;
            }
        }
        return false;
    }

    /** Camada raiz: decide quem recebe cada gesto (interface ou página). */
    private final class Root extends FrameLayout {
        private View target;

        Root(Context c) {
            super(c);
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            if (customView != null) {
                return customView.dispatchTouchEvent(ev);
            }
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                boolean toUi = uiAll || inUiRect(ev.getX(), ev.getY());
                target = toUi ? ui : pageHost;
            }
            View t = target;
            if (t == null) {
                return false;
            }
            boolean r = t.dispatchTouchEvent(ev);
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                target = null;
            }
            return r;
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        root = new Root(this);
        pageHost = new FrameLayout(this);
        root.addView(pageHost, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        pages = new PageManager(this, pageHost, this);
        ui = buildUi();
        root.addView(ui, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        boolean night = isNight();
        applyBars(night ? 0xFF191919 : 0xFFE9E9E9, night ? 0xFF000000 : 0xFFCDCDCD, night);
        ui.loadUrl("file:///android_asset/index.html");
        if (saved == null) {
            handleIntent(getIntent());
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @SuppressWarnings("deprecation")
    private WebView buildUi() {
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // A interface só carrega arquivos do próprio app (assets); isso garante o carregamento da fonte e dos scripts locais.
        s.setAllowFileAccessFromFileURLs(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setVerticalScrollBarEnabled(false);
        w.setHorizontalScrollBarEnabled(false);
        w.addJavascriptInterface(new Bridge(this), "BussolaNative");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // a interface nunca navega para fora
            }
        });
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        return w;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            emit(Js.jo("ev", "open", "url", i.getDataString()));
            i.setAction(Intent.ACTION_MAIN);
            i.setData(null);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        emit(Js.jo("ev", "sys", "dark", isNight()));
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        if (uiReady) {
            emit(Js.jo("ev", "back"));
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        pages.destroyAll();
        root.removeView(ui);
        ui.destroy();
        super.onDestroy();
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    // ---------------------------------------------------------------- ponte JS <-> app

    void fromJs(String json) {
        try {
            final JSONObject o = new JSONObject(json);
            runOnUiThread(() -> handle(o));
        } catch (Exception e) {
            // mensagem inválida: ignora
        }
    }

    @Override
    public void emit(JSONObject ev) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            deliver(ev);
        } else {
            main.post(() -> deliver(ev));
        }
    }

    private void deliver(JSONObject ev) {
        if (!uiReady) {
            queue.add(ev);
            return;
        }
        ui.evaluateJavascript("window.Bussola&&window.Bussola.onNative(" + Js.safe(ev.toString()) + ")", null);
    }

    private void toast(String msg) {
        emit(Js.jo("ev", "toast", "msg", msg));
    }

    private void handle(JSONObject o) {
        String cmd = o.optString("cmd");
        String id = o.optString("id");
        switch (cmd) {
            case "ready":
                uiReady = true;
                for (JSONObject e : queue) {
                    deliver(e);
                }
                queue.clear();
                emit(Js.jo("ev", "sys", "dark", isNight()));
                break;
            case "layout":
                setLayout(o.optBoolean("all", true), o.optJSONArray("rects"), o.optInt("inset", 0));
                break;
            case "create":
                pages.create(id, o.optString("url"), o.optBoolean("desktop"), o.optInt("zoom", 100), o.optBoolean("priv"));
                break;
            case "show":
                pages.show(id);
                break;
            case "load":
                pages.load(id, o.optString("url"));
                break;
            case "back":
                pages.back(id);
                break;
            case "forward":
                pages.forward(id);
                break;
            case "reload":
                pages.reload(id);
                break;
            case "stop":
                pages.stop(id);
                break;
            case "destroy":
                pages.destroy(id);
                break;
            case "desktop":
                pages.setDesktop(id, o.optBoolean("on"));
                break;
            case "zoom":
                pages.setZoom(id, o.optInt("pct", 100));
                break;
            case "find":
                pages.find(id, o.optString("q"));
                break;
            case "findNext":
                pages.findNext(id, o.optBoolean("fwd", true));
                break;
            case "findClear":
                pages.findClear(id);
                break;
            case "snap":
                pages.snap(id);
                break;
            case "reader":
                pages.reader(id, o.optBoolean("on"), o.optJSONObject("opts"));
                break;
            case "readerOpts":
                pages.readerOpts(id, o.optJSONObject("opts"));
                break;
            case "print":
                pages.print(id);
                break;
            case "clear":
                pages.clear(o.optString("what"));
                break;
            case "settings":
                pages.block = o.optBoolean("block", true);
                break;
            case "share":
                share(o.optString("url"), o.optString("title"));
                break;
            case "copy":
                copy(o.optString("text"));
                break;
            case "external":
                external(o.optString("url"));
                break;
            case "download":
                download(o.optString("url"), null, null, null);
                break;
            case "theme":
                applyBars(parseColor(o.optString("color"), o.optBoolean("dark") ? 0xFF191919 : 0xFFE9E9E9),
                        parseColor(o.optString("color2"), o.optBoolean("dark") ? 0xFF000000 : 0xFFCDCDCD),
                        o.optBoolean("dark"));
                break;
            case "suggest":
                suggest(o.optInt("n"), o.optString("url"));
                break;
            case "minimize":
                moveTaskToBack(true);
                break;
            default:
                break;
        }
    }

    // ---------------------------------------------------------------- layout e barras do sistema

    /**
     * A página ocupa a tela inteira e a barra de vidro flutua por cima. Aqui chegam: se a interface
     * cobre tudo, as áreas (em px de CSS) onde os toques vão para a interface e a folga que as páginas
     * deixam no fim para a barra não esconder o rodapé.
     */
    private void setLayout(boolean all, JSONArray rects, int insetCss) {
        uiAll = all;
        float d = getResources().getDisplayMetrics().density;
        int n = rects == null ? 0 : rects.length();
        int[][] out = new int[n][];
        for (int i = 0; i < n; i++) {
            JSONArray r = rects.optJSONArray(i);
            if (r == null || r.length() < 4) {
                out[i] = new int[]{0, 0, 0, 0};
            } else {
                out[i] = new int[]{
                        Math.round((float) r.optDouble(0, 0) * d), Math.round((float) r.optDouble(1, 0) * d),
                        Math.round((float) r.optDouble(2, 0) * d), Math.round((float) r.optDouble(3, 0) * d)};
            }
        }
        uiRects = out;
        pages.setInset(insetCss);
    }

    private int parseColor(String s, int fallback) {
        try {
            return Color.parseColor(s);
        } catch (Exception e) {
            return fallback;
        }
    }

    @SuppressWarnings("deprecation")
    private void applyBars(int top, int bottom, boolean dark) {
        barTop = top;
        barBottom = bottom;
        barDark = dark;
        Window w = getWindow();
        w.setStatusBarColor(top);
        w.setNavigationBarColor(bottom);
        root.setBackgroundColor(top);
        if (customView == null) {
            int f = View.SYSTEM_UI_FLAG_VISIBLE;
            if (!dark) {
                f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            w.getDecorView().setSystemUiVisibility(f);
        }
    }

    // ---------------------------------------------------------------- ações do sistema

    private void share(String url, String title) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, url);
            if (title != null && !title.isEmpty()) {
                i.putExtra(Intent.EXTRA_SUBJECT, title);
            }
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            toast("Não foi possível compartilhar.");
        }
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Bússola", text));
        }
    }

    private void external(String url) {
        try {
            Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            v.addCategory(Intent.CATEGORY_BROWSABLE);
            Intent ch = Intent.createChooser(v, "Abrir com");
            ch.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, new ComponentName[]{new ComponentName(this, MainActivity.class)});
            startActivity(ch);
        } catch (Exception e) {
            toast("Nenhum aplicativo encontrado.");
        }
    }

    @Override
    public void download(String url, String ua, String cd, String mime) {
        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                toast("Este tipo de download ainda não é suportado.");
                return;
            }
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) {
                r.setMimeType(mime);
            }
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) {
                r.addRequestHeader("Cookie", ck);
            }
            if (ua != null) {
                r.addRequestHeader("User-Agent", ua);
            }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            emit(Js.jo("ev", "download", "name", name, "url", url));
        } catch (Exception e) {
            toast("Não foi possível baixar o arquivo.");
        }
    }

    /** Sugestões de busca: baixa JSON no formato ["texto", ["sugestão", ...]]. */
    private void suggest(final int n, final String url) {
        if (!url.startsWith("https://")) {
            return;
        }
        new Thread(() -> {
            JSONArray out = new JSONArray();
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(2500);
                c.setReadTimeout(2500);
                c.setRequestProperty("User-Agent", "Mozilla/5.0");
                try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096];
                    int k;
                    while ((k = in.read(buf)) > 0 && bo.size() < 65536) {
                        bo.write(buf, 0, k);
                    }
                    JSONArray a = new JSONArray(bo.toString("UTF-8"));
                    JSONArray l = a.getJSONArray(1);
                    for (int i = 0; i < l.length() && i < 6; i++) {
                        Object x = l.get(i);
                        if (x instanceof String) {
                            out.put(x);
                        }
                    }
                }
            } catch (Exception e) {
                // sem sugestões
            } finally {
                if (c != null) {
                    c.disconnect();
                }
            }
            emit(Js.jo("ev", "suggest", "n", n, "list", out));
        }).start();
    }

    // ---------------------------------------------------------------- PageManager.Host

    @Override
    public void pickFile(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams params) {
        if (fileCb != null) {
            fileCb.onReceiveValue(null);
        }
        fileCb = cb;
        try {
            startActivityForResult(params.createIntent(), REQ_FILE);
        } catch (Exception e) {
            fileCb = null;
            cb.onReceiveValue(null);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    private String hostOf(String origin) {
        try {
            String h = Uri.parse(origin).getHost();
            return h == null ? origin : h;
        } catch (Exception e) {
            return origin;
        }
    }

    @Override
    public void askGeo(final String origin, final GeolocationPermissions.Callback cb) {
        new AlertDialog.Builder(this)
                .setTitle("Localização")
                .setMessage(hostOf(origin) + " quer saber a sua localização.")
                .setPositiveButton("Permitir", (d, w) -> {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        cb.invoke(origin, true, false);
                    } else {
                        geoCb = cb;
                        geoOrigin = origin;
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
                    }
                })
                .setNegativeButton("Negar", (d, w) -> cb.invoke(origin, false, false))
                .setOnCancelListener(d -> cb.invoke(origin, false, false))
                .show();
    }

    @Override
    public void askMedia(final PermissionRequest req) {
        final List<String> grant = new ArrayList<>();
        final List<String> need = new ArrayList<>();
        final List<String> names = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                grant.add(r);
                need.add(Manifest.permission.CAMERA);
                names.add("a câmera");
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                grant.add(r);
                need.add(Manifest.permission.RECORD_AUDIO);
                names.add("o microfone");
            } else if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) {
                grant.add(r);
            }
        }
        final String[] res = grant.toArray(new String[0]);
        if (grant.isEmpty()) {
            req.deny();
            return;
        }
        if (need.isEmpty()) {
            req.grant(res);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Permissão")
                .setMessage(hostOf(req.getOrigin().toString()) + " quer usar " + String.join(" e ", names) + ".")
                .setPositiveButton("Permitir", (d, w) -> {
                    boolean all = true;
                    for (String p : need) {
                        if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                            all = false;
                        }
                    }
                    if (all) {
                        req.grant(res);
                    } else {
                        mediaReq = req;
                        mediaRes = res;
                        requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
                    }
                })
                .setNegativeButton("Negar", (d, w) -> req.deny())
                .setOnCancelListener(d -> req.deny())
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        boolean ok = results.length > 0;
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) {
                ok = false;
            }
        }
        if (req == REQ_GEO && geoCb != null) {
            geoCb.invoke(geoOrigin, ok, false);
            geoCb = null;
        } else if (req == REQ_MEDIA && mediaReq != null) {
            if (ok) {
                mediaReq.grant(mediaRes);
            } else {
                mediaReq.deny();
            }
            mediaReq = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void showCustom(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) {
            cb.onCustomViewHidden();
            return;
        }
        customView = v;
        customCb = cb;
        v.setBackgroundColor(Color.BLACK);
        root.addView(v, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void hideCustom() {
        if (customView == null) {
            return;
        }
        View v = customView;
        WebChromeClient.CustomViewCallback cb = customCb;
        customView = null;
        customCb = null;
        root.removeView(v);
        applyBars(barTop, barBottom, barDark);
        if (cb != null) {
            cb.onCustomViewHidden();
        }
    }
}

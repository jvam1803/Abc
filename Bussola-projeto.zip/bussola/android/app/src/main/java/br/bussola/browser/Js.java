package br.bussola.browser;

import org.json.JSONException;
import org.json.JSONObject;

/** Pequenos ajudantes para montar mensagens JSON entre o app e a interface. */
final class Js {
    private Js() {}

    /** jo("ev", "start", "id", "abc") vira {"ev":"start","id":"abc"}. */
    static JSONObject jo(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) {
                o.put((String) kv[i], kv[i + 1]);
            }
        } catch (JSONException e) {
            // chave inválida: ignora
        }
        return o;
    }

    /** Texto JSON seguro para colocar dentro de uma chamada JavaScript. */
    static String safe(String json) {
        return json.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }
}

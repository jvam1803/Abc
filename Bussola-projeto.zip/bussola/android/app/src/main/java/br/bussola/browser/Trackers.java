package br.bussola.browser;

import java.util.HashSet;
import java.util.Set;

/** Lista pequena de domínios de anúncios e rastreadores que o app bloqueia. */
final class Trackers {
    private static final Set<String> HOSTS = new HashSet<>();

    static {
        String[] list = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
            "googletagmanager.com", "googletagservices.com", "adservice.google.com", "2mdn.net",
            "connect.facebook.net", "pixel.facebook.com", "scorecardresearch.com", "quantserve.com",
            "outbrain.com", "taboola.com", "criteo.com", "criteo.net", "adnxs.com", "rubiconproject.com",
            "pubmatic.com", "openx.net", "casalemedia.com", "amazon-adsystem.com", "moatads.com",
            "hotjar.com", "mixpanel.com", "segment.io", "segment.com", "amplitude.com", "adsrvr.org",
            "clarity.ms", "mc.yandex.ru", "ads-twitter.com", "analytics.twitter.com", "snap.licdn.com",
            "px.ads.linkedin.com", "analytics.tiktok.com", "adform.net", "smartadserver.com",
            "bidswitch.net", "3lift.com", "sharethrough.com", "teads.tv", "revcontent.com", "mgid.com",
            "zemanta.com", "advertising.com", "adsafeprotected.com", "doubleverify.com", "chartbeat.net",
            "newrelic.com", "nr-data.net", "bugsnag.com", "fullstory.com", "crazyegg.com", "mouseflow.com",
            "optimizely.com", "branch.io", "appsflyer.com", "adjust.com", "kochava.com"
        };
        for (String s : list) {
            HOSTS.add(s);
        }
    }

    /** Devolve o domínio da lista que corresponde ao host (ou subdomínio dele), ou null. */
    static String match(String host) {
        if (host == null) {
            return null;
        }
        String h = host.toLowerCase();
        while (true) {
            if (HOSTS.contains(h)) {
                return h;
            }
            int i = h.indexOf('.');
            if (i < 0 || h.indexOf('.', i + 1) < 0) {
                return null;
            }
            h = h.substring(i + 1);
        }
    }
}

/* Modo Leitor da Bússola.
 * Injetado pelo app em cada página (executar de novo é inofensivo).
 *   __bsReader.readable()  -> true se a página parece um artigo
 *   __bsReader.show(opts)  -> troca a página por uma versão limpa e legível (true se deu certo)
 *   __bsReader.set(opts)   -> muda tamanho, fonte e tema (white | silver | gray | black)
 * Para sair, o app simplesmente recarrega a página.
 */
(function () {
  if (window.__bsReader) return;
  var R = window.__bsReader = { _opts: {} };

  var THEMES = {
    white:  { bg: '#ffffff', fg: '#141414', sub: '#6a6a6a', rule: 'rgba(0,0,0,.16)', code: 'rgba(0,0,0,.06)', dark: false },
    silver: { bg: '#e2e2e2', fg: '#161616', sub: '#5d5d5d', rule: 'rgba(0,0,0,.18)', code: 'rgba(0,0,0,.07)', dark: false },
    gray:   { bg: '#585858', fg: '#f4f4f4', sub: '#cacaca', rule: 'rgba(255,255,255,.26)', code: 'rgba(255,255,255,.12)', dark: true },
    black:  { bg: '#000000', fg: '#e9e9e9', sub: '#9d9d9d', rule: 'rgba(255,255,255,.22)', code: 'rgba(255,255,255,.1)', dark: true }
  };
  var FONTS = {
    sans: '-apple-system,system-ui,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif',
    serif: 'Georgia,"Iowan Old Style","Times New Roman",serif'
  };
  var BAD = /(^|[\s_-])(comments?|sidebar|share|sharing|social|related|recommend\w*|promo|newsletter|subscribe|advert\w*|ads?|banner|cookie\w*|popup|modal|breadcrumbs?|menu|nav|footer|widget|toolbar|pagination|tags?)([\s_-]|$)/i;
  var SKIP = { script: 1, style: 1, noscript: 1, iframe: 1, form: 1, input: 1, button: 1, select: 1, textarea: 1, nav: 1, aside: 1,
    footer: 1, svg: 1, canvas: 1, video: 1, audio: 1, object: 1, embed: 1, link: 1, meta: 1, template: 1, dialog: 1 };
  var KEEP = { p: 1, h2: 1, h3: 1, h4: 1, h5: 1, h6: 1, ul: 1, ol: 1, li: 1, blockquote: 1, pre: 1, table: 1, thead: 1, tbody: 1, tfoot: 1,
    tr: 1, td: 1, th: 1, figure: 1, figcaption: 1, hr: 1, dl: 1, dt: 1, dd: 1, em: 1, strong: 1, b: 1, i: 1, u: 1, code: 1, sup: 1, sub: 1,
    mark: 1, small: 1, br: 1, abbr: 1, cite: 1, q: 1, kbd: 1, del: 1, ins: 1, s: 1 };

  function txt(el) { return (el.textContent || '').replace(/\s+/g, ' ').trim(); }
  function cls(el) { return (typeof el.className === 'string' ? el.className : '') + ' ' + (el.id || ''); }
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }

  // Elemento (ou ancestral próximo) que parece menu, comentário, anúncio etc.
  function bad(el, levels) {
    var e = el;
    for (var i = 0; e && e !== document.body && i < levels; i++, e = e.parentElement) {
      var n = e.localName;
      if (n === 'nav' || n === 'aside' || n === 'footer' || n === 'form') return true;
      if (e.hasAttribute('hidden') || e.getAttribute('aria-hidden') === 'true') return true;
      if (n !== 'article' && n !== 'main' && BAD.test(cls(e))) return true;
    }
    return false;
  }

  // Procura o bloco que concentra o texto da página (pontua os parágrafos e sobe para os pais).
  function pick() {
    var list = document.querySelectorAll('p, pre, blockquote'), scores = new Map();
    for (var i = 0; i < list.length && i < 1500; i++) {
      var p = list[i], t = txt(p).length;
      if (t < 50 || bad(p, 3)) continue;
      var pts = 1 + Math.min(3, Math.floor(t / 100));
      var a = p.parentElement;
      if (!a) continue;
      scores.set(a, (scores.get(a) || 0) + pts);
      var b = a.parentElement;
      if (b && b !== document.documentElement) scores.set(b, (scores.get(b) || 0) + pts / 2);
    }
    var top = Array.from(scores.entries()).sort(function (x, y) { return y[1] - x[1]; }).slice(0, 12);
    var best = null, bestScore = 0;
    top.forEach(function (en) {
      var el = en[0], s = en[1];
      if (el === document.body) s *= 0.5;
      var total = txt(el).length || 1, links = 0, as = el.getElementsByTagName('a');
      for (var j = 0; j < as.length && j < 400; j++) links += txt(as[j]).length;
      s *= Math.max(0, 1 - links / total);
      if (s > bestScore) { bestScore = s; best = el; }
    });
    if (best) {
      var art = best.closest('article');
      if (art && txt(art).length > 0.6 * txt(best).length) best = art;
    }
    return { el: best, score: bestScore };
  }

  R.readable = function () {
    try {
      var r = pick();
      return !!r.el && r.score >= 7 && txt(r.el).length >= 500;
    } catch (e) { return false; }
  };

  function abs(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return ''; } }

  // Copia só o que interessa (lista branca de elementos) para um contêiner novo.
  function build(src, out, depth, st) {
    for (var n = src.firstChild; n; n = n.nextSibling) {
      if (st.count > 12000) return;
      if (n.nodeType === 3) { out.appendChild(document.createTextNode(n.nodeValue)); st.count++; continue; }
      if (n.nodeType !== 1) continue;
      var name = n.localName;
      if (SKIP[name]) continue;
      if (n.hasAttribute('hidden') || n.getAttribute('aria-hidden') === 'true') continue;
      if (BAD.test(cls(n))) continue;
      if (name === 'img') {
        var s = n.currentSrc || n.getAttribute('src') || n.getAttribute('data-src') || n.getAttribute('data-lazy-src') || '';
        s = abs(s);
        var w = parseInt(n.getAttribute('width'), 10), h = parseInt(n.getAttribute('height'), 10);
        if (!/^(https?:|data:image)/i.test(s) || (w && w < 64) || (h && h < 64) || (n.naturalWidth && n.naturalWidth < 64)) continue;
        var im = document.createElement('img');
        im.src = s; im.alt = n.getAttribute('alt') || ''; im.loading = 'lazy'; im.decoding = 'async';
        out.appendChild(im); st.count++;
        continue;
      }
      if (name === 'a') {
        var href = abs(n.getAttribute('href') || '');
        var an = document.createElement(/^(https?:|mailto:|tel:)/i.test(href) ? 'a' : 'span');
        if (an.localName === 'a') { an.href = href; an.rel = 'noopener noreferrer'; }
        build(n, an, depth + 1, st);
        if (an.textContent.trim() || an.querySelector('img')) { out.appendChild(an); st.count++; }
        continue;
      }
      if (name === 'h1') name = 'h2';
      if (KEEP[name]) {
        if ((name === 'h2') && st.title && !st.started && norm(txt(n)) === st.title) continue;   // título repetido
        var el = document.createElement(name);
        build(n, el, depth + 1, st);
        var hasText = el.textContent.trim().length > 0 || el.querySelector('img') || name === 'hr' || name === 'br';
        if (!hasText) continue;
        if (name === 'p' || /^h\d$/.test(name)) st.started = true;
        out.appendChild(el); st.count++;
        continue;
      }
      build(n, out, depth + 1, st);   // div, section, span, picture...: só desembrulha
    }
  }

  function pageTitle(el) {
    var h1 = document.querySelector('article h1') || document.querySelector('h1');
    var og = document.querySelector('meta[property="og:title"]');
    var t = (h1 && txt(h1)) || (og && og.getAttribute('content')) || document.title || '';
    return t.trim().slice(0, 300);
  }

  function byline() {
    var m = document.querySelector('meta[name="author"]') || document.querySelector('meta[property="article:author"]');
    var a = (m && m.getAttribute('content')) || '';
    if (!a || /^https?:/i.test(a)) { var e = document.querySelector('[rel="author"], .byline, .author'); a = e ? txt(e) : ''; }
    return a.slice(0, 80);
  }

  function css(th, size, font) {
    var px = Math.round(18 * size) / 100;
    return ':host{all:initial;display:block}' +
      '.r{box-sizing:border-box;max-width:700px;margin:0 auto;padding:30px 22px 170px;color:' + th.fg + ';font:400 ' + px + 'px/1.65 ' + font + ';overflow-wrap:break-word;-webkit-text-size-adjust:none}' +
      '.r *{box-sizing:border-box}' +
      'h1{font-size:1.65em;line-height:1.2;font-weight:700;margin:.1em 0 .4em;letter-spacing:-.015em}' +
      '.m{color:' + th.sub + ';font-size:.76em;margin:0 0 1.8em;font-family:-apple-system,system-ui,Roboto,sans-serif}' +
      'h2,h3,h4,h5,h6{line-height:1.3;margin:1.6em 0 .5em;font-weight:700}h2{font-size:1.3em}h3{font-size:1.15em}h4,h5,h6{font-size:1em}' +
      'p{margin:0 0 1.15em}' +
      'a{color:inherit;text-decoration:underline;text-decoration-color:' + th.rule + ';text-underline-offset:3px}' +
      'img{display:block;max-width:100%;height:auto;margin:1.2em auto;border-radius:14px}' +
      'figure{margin:1.3em 0}figcaption{color:' + th.sub + ';font-size:.8em;margin-top:.4em}' +
      'blockquote{margin:1.3em 0;padding:.1em 0 .1em 1em;border-left:3px solid ' + th.rule + ';color:' + th.sub + '}' +
      'pre{background:' + th.code + ';padding:12px 14px;border-radius:12px;overflow-x:auto;font:.82em/1.5 ui-monospace,Menlo,Consolas,monospace}' +
      'code{background:' + th.code + ';padding:.1em .3em;border-radius:6px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.9em}pre code{background:none;padding:0}' +
      'ul,ol{padding-left:1.4em;margin:0 0 1.15em}li{margin:.35em 0}' +
      'table{border-collapse:collapse;display:block;overflow-x:auto;max-width:100%;font-size:.9em}td,th{border:1px solid ' + th.rule + ';padding:6px 10px}' +
      'hr{border:0;border-top:1px solid ' + th.rule + ';margin:1.8em 0}';
  }

  R.set = function (o) {
    if (!R._st) return;
    var cur = R._opts = Object.assign(R._opts || {}, o || {});
    var th = THEMES[cur.theme] || THEMES.white;
    var size = Math.max(60, Math.min(260, +cur.size || 100));
    R._st.textContent = css(th, size, FONTS[cur.font] || FONTS.sans);
    var de = document.documentElement, bd = document.body;
    de.style.setProperty('background', th.bg, 'important');
    de.style.setProperty('color-scheme', th.dark ? 'dark' : 'light');
    de.style.setProperty('overflow-x', 'hidden', 'important');
    de.style.setProperty('overflow-y', 'auto', 'important');
    de.style.setProperty('height', 'auto', 'important');
    bd.style.setProperty('background', th.bg, 'important');
    ['margin', 'padding'].forEach(function (k) { bd.style.setProperty(k, '0', 'important'); });
    bd.style.setProperty('display', 'block', 'important');
    bd.style.setProperty('position', 'static', 'important');
    bd.style.setProperty('height', 'auto', 'important');
    bd.style.setProperty('min-height', '100vh', 'important');
    bd.style.setProperty('overflow', 'visible', 'important');
  };

  R.show = function (opts) {
    try {
      var r = pick();
      if (!r.el || r.score < 5) return false;
      var title = pageTitle(r.el), st = { count: 0, started: false, title: norm(title) };
      var body = document.createElement('div');
      build(r.el, body, 0, st);
      var plain = txt(body);
      if (plain.length < 300) return false;
      var mins = Math.max(1, Math.round(plain.split(' ').length / 200));

      var host = document.createElement('div');
      host.id = '__bs_reader';
      var root = host.attachShadow({ mode: 'open' });
      R._st = document.createElement('style');
      var art = document.createElement('article');
      art.className = 'r';
      var h1 = document.createElement('h1'); h1.textContent = title;
      var site = (location.hostname || '').replace(/^www\./, ''), by = byline();
      var m = document.createElement('div'); m.className = 'm';
      m.textContent = [by, site, mins + ' min de leitura'].filter(Boolean).join(' · ');
      art.appendChild(h1); art.appendChild(m);
      while (body.firstChild) art.appendChild(body.firstChild);
      root.appendChild(R._st); root.appendChild(art);

      document.body.textContent = '';
      document.body.appendChild(host);
      R.set(opts || {});
      window.scrollTo(0, 0);
      return true;
    } catch (e) { return false; }
  };
})();
